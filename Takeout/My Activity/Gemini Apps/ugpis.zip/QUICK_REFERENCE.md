# UGPIS-Ω Quick Reference

## File Structure

**Main Code:** `UGPIS_OMEGA_FIXED.py` (2,249 lines)

**Section Breakdown:**
- **Imports & Logging** (1-60) — Structured JSON logging setup
- **Content Polish Pipeline** (65-200) — Linguistic normalization (optional)
- **ECP** (205-290) — Secure data ingestion with HMAC signatures
- **Tone Normalization** (295-330) — Optional external comm polishing
- **DIT** (335-450) — Deterministic integrity with cadence throttling
- **Clinical Validator** (455-510) — Domain-specific signal coherence checks
- **OBSERVE Data Structures** (515-850) — Pediatric early-warning enums, dataclasses, audit trail
- **FORTRESS 2.0** (855-1100) — Predictive state controller with transition logging
- **URE** (1105-1400) — Multi-dimensional operational regime classification
- **EDDP** (1405-1650) — Evaluation, distribution, dashboarding with explicit metrics
- **GSA** (1655-1900) — Governance, state substrate, trajectory tracking, constitutional governor
- **UGPISOmegaController** (1905-2050) — Master orchestrator tying all subsystems
- **FastAPI Endpoints** (2055-2249) — REST API + clinical validators + diagnostics

---

## Critical Classes & Their Changes

### ContentPolishPipeline (was ZTGKT)
```python
pipeline = ContentPolishPipeline(execution_gateway=text_gen_fn)
result = await pipeline.execute(prompt)
# Returns: {"execution_status", "validated_content", "payload_signature", ...}
```
- **Change:** Now opt-in. Removes first-person pronouns, hedging, etc.
- **Clinical impact:** Does NOT affect OBSERVE risk signals
- **Usage:** Only for external communications (reports, summaries)

### ClinicalSignalValidator (NEW)
```python
validator = ClinicalSignalValidator()
is_valid, failures = validator.validate_signal(signal_text)
# Returns: (bool, List[str])
```
- **REQUIRES:** Temporal markers (onset, 14:32, "within 1 hour")
- **REQUIRES:** Numeric values (85%, 142 bpm, 3.2 mmol/L)
- **REQUIRES:** Clinical context (patient, neonate, vital, monitor)
- **Usage:** Validate all inbound signals before risk evaluation

### PredictiveStateController (was FORTRESS 2.0)
```python
fortress = PredictiveStateController(fallback_provider, config)
result = fortress.process_step(payload, error_input, live_signal)
# Returns: {"computed_output", "blending_coefficient", "operational_mode", 
#           "mode_changed", "evaluated_variance", ...}
```
- **NEW:** Logs every NOMINAL↔OVERRIDE transition with reason
- **Access transitions:** `fortress.state_transitions` → List[FortressStateTransition]
- **Thresholds:** engagement=0.55, disengagement=0.35 (configurable)
- **Variance:** Calculated from error history, signal verification, divergence metrics

### SystemRegimeClassifier (was URE stub)
```python
classifier = SystemRegimeClassifier(config)
profile = classifier.classify_current_regime(metrics)
# Returns: RegimeClassificationProfile with probability distribution
```
- **Features:** 11 operational metrics (dropout, escalation, backlog, latency, etc.)
- **Regimes:** STABLE, SURGE, RESOURCE_OVERLOAD, ANOMALOUS_CRITICAL, SATURATED, CONTESTED
- **Output:** Probability distribution + dominant regime + entropy
- **TODO:** Replace feature weights with learned thresholds from NCH data

### GlobalStateSubstrate (was mutable black hole)
```python
SYSTEM_GLOBALS.record_state_transition(actor, description, pre_state, post_state)
# Now logs all mutations: integrity_debt_balance, emergency_escalation_tier, etc.
```
- **NEW:** Every state change is recorded with timestamp + pre/post snapshot
- **Access history:** `SYSTEM_GLOBALS.state_transition_history`
- **Logged events:** EvolutionaryRecursionEngine remediation, GSA mutation, etc.

### AppendOnlyAuditTrail
```python
audit_trail = AppendOnlyAuditTrail()
audit_trail.commit_entry(entry)
is_valid = audit_trail.verify_chain_integrity()
ledger_json = audit_trail.export_serialized_ledger()
```
- **Blockchain-style:** SHA-256 hash chain, tamper-proof
- **Export:** Full JSON ledger for compliance review
- **Verification:** Can be verified independently with genesis hash

---

## Key Metrics & Their Meanings

### FORTRESS Variance (composite_variance)
- **Range:** 0.0 - 0.99
- **Components:**
  - Error history variance (std dev of past errors)
  - Verification penalty (0.5 if source_id or signature missing)
  - Divergence metric (if error > 12.0 and "stable"/"healthy" in content)
  - Prediction error (difference between projected and actual state)
- **Engagement:** ≥ 0.55 → OVERRIDE mode
- **Disengagement:** ≤ 0.35 → back to NOMINAL

### URE Composite Risk Score
- **Range:** 0.0 - 1.0
- **Components:**
  - dropout_rate × 2.0
  - escalation_rate × 1.5
  - reentry_rate × 1.5
  - backlog_depth × 0.01
  - Entropy adjustment (1.0 + entropy × 0.15)
- **Risk escalation threshold:** ≥ 0.75
- **Calculated energy threshold:** ≥ 0.10

### Clinical Signal Validation Failures
- **"Missing temporal specificity"** → No time reference (hour, minute, onset, etc.)
- **"Missing quantitative values"** → No vital signs or measurements (bpm, mmHg, %, etc.)
- **"Missing clinical context"** → No patient/neonate/monitor/alert references

---

## Common Workflows

### 1. Process Single Clinical Alert
```python
# POST /process_inbound
payload = {
    "title": "Neonatal Desaturation",
    "text": "Patient in NICU bed 5. SpO2 dropped from 96% to 82% at 14:32. Heart rate increased to 168 bpm. On supplemental oxygen."
}
response = requests.post("http://localhost:8000/process_inbound", json=payload)
risk_signal = response.json()["OBSERVE_risk_signal"]
fortress_metrics = response.json()["FORTRESS_metrics"]
```

### 2. Validate Clinical Signal Before Ingestion
```python
# POST /validate_clinical_signal
payload = {"text": "Patient stable."}
response = requests.post("http://localhost:8000/validate_clinical_signal", json=payload)
if not response.json()["is_clinically_valid"]:
    print("Validation failures:", response.json()["validation_failures"])
    # Failures: ["Missing temporal specificity", "Missing quantitative values", ...]
```

### 3. Audit System State for Compliance
```python
# GET /audit_trail
response = requests.get("http://localhost:8000/audit_trail")
audit_data = response.json()
print(f"Chain verified: {audit_data['chain_integrity_verified']}")
print(f"Total entries: {audit_data['audit_entries']}")

# Export for review
with open("audit_export.json", "w") as f:
    json.dump(audit_data["ledger_export"], f, indent=2)
```

### 4. Monitor Real-Time System Health
```python
# GET /system_diagnostics
response = requests.get("http://localhost:8000/system_diagnostics")
diag = response.json()
print(f"Health: {diag['global_state']['health_index']}")
print(f"FORTRESS mode: {diag['fortress_state']['current_mode']}")
print(f"Regime transitions: {len(diag['fortress_state']['total_transitions'])}")
```

### 5. Inspect FORTRESS Mode Changes
```python
response = requests.post("http://localhost:8000/process_inbound", json=payload)
transitions = response.json()["FORTRESS_state_transitions"]
for t in transitions:
    print(f"{t['timestamp']}: {t['previous_mode']} -> {t['new_mode']}")
    print(f"  Reason: {t['reason']}")
    print(f"  Trigger variance: {t['trigger_variance']}")
```

---

## Debugging Tips

### Clinical Signal Not Validating?
```python
response = requests.post("http://localhost:8000/validate_clinical_signal", 
                        json={"text": your_signal_text})
failures = response.json()["validation_failures"]
# Check for missing:
# - Time markers (onset, 14:32, "within 1 hour", etc.)
# - Vital signs (85%, 142 bpm, 3.2 mmol/L, etc.)
# - Patient context (neonate, patient, monitor, alert, etc.)
```

### FORTRESS Not Transitioning?
```python
fortress_output = response.json()["FORTRESS_metrics"]
print(f"Mode: {fortress_output['operational_mode']}")
print(f"Mode changed: {fortress_output['mode_changed']}")
print(f"Variance: {fortress_output['evaluated_variance']}")
# If variance is between 0.35 and 0.55 (deadband), mode won't change
```

### URE Regime Not Making Sense?
```python
ure_output = response.json()["URE_summary"]
print(f"Regime scores: {ure_output['regime_scores']}")
print(f"Confidence: {ure_output['regime_confidence']}")
print(f"Entropy: {ure_output['regime_entropy']}")
# High entropy = uncertain (low confidence)
# Low entropy = certain (high confidence)
# Check individual metrics in current_metrics to see what drove classification
```

### Audit Chain Broken?
```python
response = requests.get("http://localhost:8000/audit_trail")
if not response.json()["chain_integrity_verified"]:
    print("ERROR: Audit trail has been tampered with!")
    print(f"Expected chain hash: {response.json()['ledger_export'][-1]['immutable_block_hash']}")
```

---

## Performance Tuning

### Reduce Memory Usage
- Archive audit trail entries older than 30 days
- Implement ledger rotation (max 10k entries per file)
- Clear FORTRESS error_history when not transitioning

### Improve Throughput
- Run multiple instances behind load balancer
- Cache clinical validation patterns (if using heavy regex)
- Pre-compute regime scores for common metric combinations

### Reduce Latency
- Disable tone normalization if not needed (`enable_tone_normalization=False`)
- Use ConnectionPool for multiple requests
- Consider caching EDDP metric calculations

---

## Configuration Checklist

Before deploying to NCH:

- [ ] **FORTRESS thresholds:** Calibrate engagement/disengagement based on clinical experience
- [ ] **URE feature weights:** Learn from 6-12 months of operational data
- [ ] **EDDP metrics:** Replace 100000 (capacity) and 5000 (FPR) with actual NCH values
- [ ] **GSA governance:** Adjust consensus threshold and temporal locking to match institutional policy
- [ ] **Clinical validator:** Test with 100+ real clinical signals for false positives/negatives
- [ ] **Fallback value:** Set FORTRESS fallback_provider to match your risk tolerance (currently 50.0)
- [ ] **Logging retention:** Implement audit trail archival strategy
- [ ] **Authentication:** Add API key/OAuth if exposing over network
- [ ] **Database:** Implement persistent audit trail storage
- [ ] **Monitoring:** Wire up Prometheus metrics to Grafana

---

## Links

- **Full Code:** `/mnt/user-data/outputs/UGPIS_OMEGA_FIXED.py`
- **API Docs:** `/mnt/user-data/outputs/API_DOCUMENTATION.md`
- **Architectural Fixes:** `/mnt/user-data/outputs/FIXES_APPLIED.md`

---

**Status:** Ready for institutional calibration and pilot deployment  
**Last Updated:** 2026-06-08
