"""
evaluate_fraud_army.py
======================

Implements the *exact* protocol described in the Synthetic Fraud Army governance
document — NOT a fraud classifier.

The fraud army is a negative-control population. You do not "catch" it. You run
it against the IVR pre-change and post-change and check whether your change made
the system MORE legible to hostile automation (higher determinism, lower
variance, faster convergence). The same change that helps real borrowers can
simultaneously increase exposure to bots; this harness surfaces that tension.

Output, per the doc's REPORTING OUTPUTS section:
  - summary table by intent archetype
  - delta indicators (pre vs post)
  - executive annotation: "No material exposure increase" or
    "Exposure increase detected"

There is deliberately no accuracy / precision / "90% detection" number here:
the design produces a comparative exposure delta, not a labeled classification,
so an accuracy figure would be meaningless. (The earlier ATS-Governor docs
asserted "90%+ detection accuracy / Brier 0.08" — those numbers were never
measured and do not apply to this construct.)
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import numpy as np

from sentinel_unified import Metrics

ARCHETYPES = {
    "A": "Account State Confirmation",
    "B": "Identity Surface Mapping",
    "C": "Eligibility/Status Boundary Probing",
    "D": "Temporal Consistency Testing",
    "E": "Process Chaining Discovery",
}

# Material-change epsilon on the exposure scale [0,1].
EXPOSURE_EPSILON = 0.02


@dataclass
class SyntheticEntity:
    synthetic_id: str
    primary: str          # archetype letter
    secondary: str
    time_window: str
    path_variance: str    # Low/Medium/High
    retry_cadence: str
    human_likeness: str


def parse_fraud_army(path: str | Path) -> List[SyntheticEntity]:
    text = Path(path).read_text(encoding="utf-8")
    entities: List[SyntheticEntity] = []
    for block in text.split("Synthetic_ID:")[1:]:
        d = {}
        first, *rest = block.splitlines()
        d["Synthetic_ID"] = first.strip()
        for line in rest:
            if ":" in line:
                k, v = line.split(":", 1)
                d[k.strip()] = v.strip()
            if line.strip().startswith("---"):
                break
        if "Primary_Intent" not in d:
            continue
        entities.append(SyntheticEntity(
            synthetic_id=d["Synthetic_ID"],
            primary=d["Primary_Intent"].strip()[0],
            secondary=(d.get("Secondary_Intent", "?").strip()[:1] or "?"),
            time_window=d.get("Time_Window_Bias", ""),
            path_variance=d.get("Path_Variance_Class", ""),
            retry_cadence=d.get("Retry_Cadence_Class", ""),
            human_likeness=d.get("Human_Likeness_Index", ""),
        ))
    return entities


# Per-archetype weighting of automation-relevant signals, taken from the
# "Signals observed" lines in the governance doc. Each maps the IVR metric state
# to an exposure contribution in [0,1] (higher = more legible to automation).
def _signals(m: Metrics, time_variance: float) -> Dict[str, float]:
    return {
        "determinism": m.determinism_index,                 # response uniformity / predictability
        "dwell_stability": 1.0 - min(1.0, m.abandon_rate),  # stable dwell time
        "boundary_sharpness": m.determinism_index,          # clear allowed/denied thresholds
        "low_time_variance": 1.0 - min(1.0, time_variance), # consistency across time windows
        "state_carryover": 1.0 - min(1.0, m.ivr_reentry_rate),  # smooth carryover -> chaining
    }


_ARCHETYPE_WEIGHTS = {
    "A": {"determinism": 0.5, "dwell_stability": 0.5},
    "B": {"determinism": 0.8, "dwell_stability": 0.2},
    "C": {"boundary_sharpness": 0.7, "determinism": 0.3},
    "D": {"low_time_variance": 1.0},
    "E": {"state_carryover": 0.7, "determinism": 0.3},
}


def archetype_exposure(letter: str, m: Metrics, time_variance: float) -> float:
    sig = _signals(m, time_variance)
    w = _ARCHETYPE_WEIGHTS[letter]
    return float(sum(w[k] * sig[k] for k in w))


def run_detection_gate(entities: List[SyntheticEntity], pre: Metrics, post: Metrics,
                       pre_time_variance: float, post_time_variance: float) -> Dict:
    """Pre/post exposure comparison weighted by the real archetype population."""
    counts = Counter(e.primary for e in entities)
    total = sum(counts.values())
    rows = []
    weighted_delta = 0.0
    for letter, name in ARCHETYPES.items():
        n = counts.get(letter, 0)
        e_pre = archetype_exposure(letter, pre, pre_time_variance)
        e_post = archetype_exposure(letter, post, post_time_variance)
        delta = e_post - e_pre
        if delta > EXPOSURE_EPSILON:
            label = "Risk-Increasing"
        elif delta < -EXPOSURE_EPSILON:
            label = "Regressive"        # exposure dropped (good for security)
        else:
            label = "Neutral"
        rows.append({
            "archetype": f"{letter} — {name}", "n": n,
            "share": n / total if total else 0.0,
            "exposure_pre": round(e_pre, 4), "exposure_post": round(e_post, 4),
            "delta": round(delta, 4), "label": label,
        })
        weighted_delta += (n / total if total else 0.0) * delta

    annotation = ("Exposure increase detected"
                  if weighted_delta > EXPOSURE_EPSILON
                  else "No material exposure increase")
    return {"rows": rows, "population_weighted_delta": round(weighted_delta, 4),
            "annotation": annotation, "total_entities": total}


def _print_report(report: Dict) -> None:
    print(f"Population: {report['total_entities']} synthetic entities (detection-only)")
    print(f"{'Archetype':<42}{'n':>6}{'pre':>9}{'post':>9}{'Δ':>9}  label")
    print("-" * 88)
    for r in report["rows"]:
        print(f"{r['archetype']:<42}{r['n']:>6}{r['exposure_pre']:>9.3f}"
              f"{r['exposure_post']:>9.3f}{r['delta']:>+9.3f}  {r['label']}")
    print("-" * 88)
    print(f"Population-weighted exposure delta: {report['population_weighted_delta']:+.4f}")
    print(f"EXECUTIVE ANNOTATION: {report['annotation']}")


if __name__ == "__main__":
    up = "/mnt/user-data/uploads"
    entities = parse_fraud_army(f"{up}/synthetic_fraud_army_2000.txt")

    base = Metrics(determinism_index=0.95, abandon_rate=0.055, ivr_reentry_rate=0.10)

    print("=" * 88)
    print("SCENARIO 1: change that HARDENS the IVR (raises determinism, smooths flow)")
    print("  good for borrowers, but more legible to automation")
    print("=" * 88)
    hardened = Metrics(determinism_index=0.995, abandon_rate=0.03, ivr_reentry_rate=0.04)
    _print_report(run_detection_gate(entities, base, hardened,
                                     pre_time_variance=0.30, post_time_variance=0.10))

    print()
    print("=" * 88)
    print("SCENARIO 2: change that adds randomized verification (lowers determinism)")
    print("  mild friction for borrowers, reduces automation exposure")
    print("=" * 88)
    randomized = Metrics(determinism_index=0.80, abandon_rate=0.07, ivr_reentry_rate=0.12)
    _print_report(run_detection_gate(entities, base, randomized,
                                     pre_time_variance=0.30, post_time_variance=0.30))
