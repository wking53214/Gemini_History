"""
test_properties.py
==================

Property-based tests (hypothesis) that the example-based unit tests in the
earlier ATS-Governor suite could not have caught. The point: the original
inv_logit used 1/(1+exp(-x)) which OverflowErrors for large x; the example
tests only checked x=0, +-1000. Hypothesis fuzzes the whole float range and
proves the scipy.special replacement holds, plus core engine invariants.

Run:  pytest test_properties.py -q     (or: python test_properties.py)
"""
import math

import numpy as np
from hypothesis import given, settings
from hypothesis import strategies as st

from sentinel_unified import (
    Metrics, RunContext, ResilienceConfig, UnifiedResilienceEngine,
    safe_expit, safe_logit,
)
from datetime import datetime, timezone


def _naive_inv_logit(x: float) -> float:
    """The original hand-rolled version — overflows for very negative x."""
    return 1.0 / (1.0 + math.exp(-x))


# ---- numerics ----------------------------------------------------------------

@given(st.floats(min_value=-1e6, max_value=1e6, allow_nan=False, allow_infinity=False))
def test_safe_expit_bounded_everywhere(x):
    y = safe_expit(x)
    assert 0.0 <= y <= 1.0
    assert math.isfinite(y)


def test_naive_overflows_where_safe_does_not():
    """Concrete proof the upgrade matters: the naive form raises, scipy doesn't."""
    big_negative = -1000.0
    raised = False
    try:
        _naive_inv_logit(big_negative)
    except OverflowError:
        raised = True
    assert raised, "expected the naive 1/(1+exp(-x)) to overflow at x=-1000"
    # the replacement is fine
    assert safe_expit(big_negative) == 0.0


@given(st.floats(min_value=1e-9, max_value=1 - 1e-9))
def test_logit_expit_roundtrip(p):
    assert math.isclose(safe_expit(safe_logit(p)), p, rel_tol=1e-6, abs_tol=1e-9)


# ---- engine invariants -------------------------------------------------------

metric_floats = st.floats(min_value=0.0, max_value=1.0, allow_nan=False)
rate = lambda: metric_floats


@st.composite
def metrics(draw):
    return Metrics(
        containment=draw(rate()), aht=draw(st.floats(0.0, 1200.0)),
        abandon_rate=draw(rate()), ivr_reentry_rate=draw(rate()),
        escalation_rate=draw(rate()), callback_rate=draw(rate()),
        repeat_auth_rate=draw(rate()), determinism_index=draw(rate()),
        queue_depth=draw(st.floats(0.0, 500.0)),
    )


@settings(max_examples=300)
@given(metrics(), metrics())
def test_risk_score_always_unit_interval(base, cur):
    eng = UnifiedResilienceEngine()
    ctx = RunContext("prop", datetime.now(timezone.utc))
    r = eng.evaluate(base, cur, ctx)
    assert 0.0 <= r.risk_score <= 1.0
    assert r.lyapunov_energy >= 0.0
    assert math.isfinite(r.lyapunov_energy)
    # regime distribution sums to 1 (within 4-decimal display rounding)
    assert abs(sum(r.regime_scores.values()) - 1.0) < 1e-3


@settings(max_examples=200)
@given(metrics())
def test_noop_change_is_zero_energy_and_zero_risk(m):
    """One-sided risk fix: identical baseline/current => no signal."""
    eng = UnifiedResilienceEngine(ResilienceConfig(risk_one_sided=True))
    ctx = RunContext("noop", datetime.now(timezone.utc))
    r = eng.evaluate(m, m, ctx)
    assert r.lyapunov_energy == 0.0
    assert r.risk_score == 0.0


@settings(max_examples=200)
@given(metrics())
def test_old_formula_would_inflate_noop_risk(m):
    """Documents WHY the fix matters: old two-sided formula scores a no-op > 0."""
    eng = UnifiedResilienceEngine(ResilienceConfig(risk_one_sided=False))
    ctx = RunContext("noop-old", datetime.now(timezone.utc))
    r = eng.evaluate(m, m, ctx)
    assert r.risk_score > 0.0  # this is the bug the one-sided fix removes


# ---- hardening: bounds, confidence, no-crash ---------------------------------

# strategy that deliberately produces out-of-range and non-finite values
wild = st.one_of(
    st.floats(min_value=-1e6, max_value=1e6, allow_nan=False, allow_infinity=False),
    st.sampled_from([float("nan"), float("inf"), float("-inf"), -5.0, 1.7, 42.0]),
)


@st.composite
def wild_metrics(draw):
    return Metrics(
        containment=draw(wild), aht=draw(wild), abandon_rate=draw(wild),
        ivr_reentry_rate=draw(wild), escalation_rate=draw(wild),
        callback_rate=draw(wild), repeat_auth_rate=draw(wild),
        determinism_index=draw(wild), queue_depth=draw(wild),
    )


@settings(max_examples=400)
@given(wild_metrics(), wild_metrics())
def test_corrupted_input_never_crashes_and_stays_bounded(base, cur):
    """Defensive bounds: garbage in (NaN/Inf/out-of-range) must not crash, and the
    verdict must remain well-formed with confidence in [0,1]."""
    eng = UnifiedResilienceEngine()
    ctx = RunContext("wild", datetime.now(timezone.utc))
    r = eng.evaluate(base, cur, ctx)  # must not raise
    assert 0.0 <= r.risk_score <= 1.0
    assert 0.0 <= r.confidence <= 1.0
    assert math.isfinite(r.lyapunov_energy) and r.lyapunov_energy >= 0.0
    # if anything was out of bounds, it must be reported and quality degraded
    if r.bound_violations:
        assert r.data_quality.startswith("degraded")
        assert r.confidence < 1.0


def test_sanitize_clamps_nan_and_out_of_range():
    m = Metrics(abandon_rate=1.7, aht=-5.0, determinism_index=float("nan"))
    assert m.check_bounds()                      # reports violations
    s = m.sanitized()
    assert 0.0 <= s.abandon_rate <= 1.0
    assert s.aht >= 0.0
    assert math.isfinite(s.determinism_index)
    assert not s.check_bounds()                  # clean after sanitize


def test_clean_input_has_full_confidence_modulo_entropy():
    """A clean, low-entropy (clearly-stable) eval should not be flagged degraded."""
    eng = UnifiedResilienceEngine()
    base = Metrics(containment=0.82, abandon_rate=0.05, determinism_index=0.95)
    r = eng.evaluate(base, base, RunContext("clean", datetime.now(timezone.utc)))
    assert r.data_quality == "ok"
    assert not r.bound_violations


if __name__ == "__main__":
    import subprocess, sys
    sys.exit(subprocess.call(["python", "-m", "pytest", __file__, "-q"]))
