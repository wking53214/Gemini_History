"""
operational_data.py
====================

Grounds the engine in the real call-center telemetry instead of hand-set numbers.

Loads the three intraday distributions (volume, AHT index, abandonment) and:
  - derives an empirical baseline Metrics (volume-weighted),
  - calibrates a defensible Lyapunov energy_threshold from the natural
    cell-to-cell variation actually present in the data,
  - exposes expected(day, time) so a proposed change can be scored against
    realistic time-of-day load rather than an average.

Uses pandas (the originals hand-rolled CSV parsing). Compatible with pandas 3.0
(DataFrame.map, not the removed applymap).
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from sentinel_unified import Metrics, ResilienceConfig, StabilityVerifier

DAYS = ["MON", "TUE", "WED", "THU", "FRI", "SAT"]


def _num(x) -> float:
    if pd.isna(x):
        return np.nan
    s = str(x).strip().replace("%", "").replace(",", "")
    if s in ("", "-"):
        return np.nan
    try:
        return float(s)
    except ValueError:
        return np.nan


def load_intraday(path: str | Path) -> pd.DataFrame:
    """Return a time-indexed DataFrame of day columns; drops the totals row."""
    df = pd.read_csv(path, sep="\t", dtype=str).rename(columns=lambda c: c.strip())
    df = df.rename(columns={df.columns[0]: "TIME"})
    is_total = df["TIME"].isna() | (df["TIME"].astype(str).str.strip() == "")
    day_cols = [c for c in df.columns if c != "TIME"]
    body = df[~is_total].copy().set_index("TIME")
    return body[day_cols].map(_num)


class OperationalProfile:
    """Empirical baseline + calibration derived from real intraday telemetry."""

    def __init__(self, volume: pd.DataFrame, aht_index: pd.DataFrame,
                 abandon_pct: pd.DataFrame, base_aht_seconds: float = 300.0):
        self.volume = volume
        self.aht_index = aht_index                 # percent of standard (~100)
        self.abandon = abandon_pct                 # percent
        self.base_aht_seconds = base_aht_seconds

    @classmethod
    def from_files(cls, volume_path: str, aht_path: str, abandon_path: str,
                   base_aht_seconds: float = 300.0) -> "OperationalProfile":
        return cls(load_intraday(volume_path), load_intraday(aht_path),
                   load_intraday(abandon_path), base_aht_seconds)

    # ---- baseline ----------------------------------------------------------

    def volume_weighted_abandon(self) -> float:
        w = self.volume.reindex_like(self.abandon).values
        a = self.abandon.values / 100.0
        mask = ~np.isnan(a) & ~np.isnan(w)
        return float(np.sum(a[mask] * w[mask]) / np.sum(w[mask]))

    def mean_aht_index(self) -> float:
        return float(np.nanmean(self.aht_index.values) / 100.0)

    def empirical_baseline(self) -> Metrics:
        """A baseline Metrics anchored to observed abandon and AHT.
        Dimensions not present in the feed (reentry, escalation, queue, ...) are
        left at neutral starting points and should be set from your own data."""
        return Metrics(
            containment=0.82,
            aht=self.base_aht_seconds * self.mean_aht_index(),
            abandon_rate=self.volume_weighted_abandon(),
            ivr_reentry_rate=0.10,
            escalation_rate=0.15,
            determinism_index=0.95,
            queue_depth=12.0,
        )

    def expected(self, day: str, time: str) -> Tuple[float, float]:
        """(abandon_rate, aht_seconds) expected at a given day/time cell."""
        a = self.abandon.at[time, day] if time in self.abandon.index else np.nan
        h = self.aht_index.at[time, day] if time in self.aht_index.index else np.nan
        a = self.volume_weighted_abandon() if np.isnan(a) else a / 100.0
        h = self.mean_aht_index() if np.isnan(h) else h / 100.0
        return a, self.base_aht_seconds * h

    # ---- calibration -------------------------------------------------------

    def calibrate_energy_threshold(self, config: ResilienceConfig | None = None,
                                   percentile: float = 95.0) -> Dict[str, float]:
        """Compute the Lyapunov energy of every (day,time) cell vs the empirical
        baseline, over the dimensions the feed actually observes (abandon + AHT),
        and report the distribution. A threshold at the given percentile sits just
        above normal operational variation, so only genuinely abnormal change trips
        REGRESSIVE.

        Note: only abandon_rate and AHT vary here (that's all the feed carries);
        other metrics are held at baseline. Recalibrate when you have richer data.
        """
        cfg = config or ResilienceConfig()
        verifier = StabilityVerifier(cfg)
        base = self.empirical_baseline()
        energies = []
        for day in [d for d in DAYS if d in self.abandon.columns]:
            for time in self.abandon.index:
                a, h = self.expected(day, time)
                cell = Metrics(
                    containment=base.containment, aht=h, abandon_rate=a,
                    ivr_reentry_rate=base.ivr_reentry_rate,
                    escalation_rate=base.escalation_rate,
                    determinism_index=base.determinism_index,
                    queue_depth=base.queue_depth,
                )
                energies.append(verifier.energy(base, cell))
        arr = np.array(energies, dtype=float)
        return {
            "n_cells": int(arr.size),
            "median": float(np.median(arr)),
            "p90": float(np.percentile(arr, 90)),
            "p95": float(np.percentile(arr, 95)),
            "p99": float(np.percentile(arr, 99)),
            "max": float(arr.max()),
            "recommended_threshold": float(np.percentile(arr, percentile)),
        }


if __name__ == "__main__":
    up = "/mnt/user-data/uploads"
    prof = OperationalProfile.from_files(
        f"{up}/intraday_distribution_voice.txt",
        f"{up}/intraday_distribution_voice_AHT.txt",
        f"{up}/intraday_distribution_voice_abandons.txt",
    )
    base = prof.empirical_baseline()
    print("Empirical baseline from real telemetry:")
    print(f"  volume-weighted abandon = {prof.volume_weighted_abandon():.3%}")
    print(f"  mean AHT index          = {prof.mean_aht_index():.1%}  -> {base.aht:.0f}s")
    print(f"  baseline.abandon_rate   = {base.abandon_rate:.4f}")
    print()
    cal = prof.calibrate_energy_threshold(percentile=95.0)
    print("Energy threshold calibration (abandon + AHT dims):")
    for k, v in cal.items():
        print(f"  {k:22} {v:.4f}" if isinstance(v, float) else f"  {k:22} {v}")
    print()
    a, h = prof.expected("SAT", "12:00")
    print(f"Worst observed cell SAT 12:00 -> abandon {a:.1%}, AHT {h:.0f}s")
