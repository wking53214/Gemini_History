"""
sentinel_unified.py
===================

A single consolidated engine that merges the best ideas scattered across the
Sentinel family (v1 design doc, sentinel.py / transported_sentinelv2, the
FastAPI service, sentinel_ivr_production, and v3 "Universal Resilience Engine").

What this pulls from where
--------------------------
  v3 (Sentinel_v3_0.py)         : externalized ResilienceConfig, Lyapunov
                                  stability energy, Shannon-entropy on the
                                  regime distribution, entropy-modulated risk.
  sentinel.py / v2              : RatePair (keep clipped AND unclipped rates),
                                  TemporalWindow.velocity, RunContext learning
                                  charter, hash-chained AuditLog.
  sentinel_api.py               : echo-state Reservoir forecaster + a
                                  ForecastTracker trust-gate so degraded
                                  predictions cannot steer governance.

Library upgrades over the originals
-----------------------------------
  scipy.special.expit / logit   : numerically stable; removes the hand-rolled
                                  inv_logit(...) with the manual +/-700 clamp and
                                  v3's bare 1/(1+exp(-x)) (which overflows).
  scipy.stats.entropy           : replaces the hand-rolled Shannon loop.
  numpy                         : vectorized Lyapunov energy + reservoir.

Correctness fix carried in here
-------------------------------
  v3's risk = expit(raw)*modifier with raw >= 0 means a no-op change still
  scores ~0.25-0.5. Here risk uses (2*expit(raw)-1) so zero change -> zero risk.
  Set config.risk_one_sided=False to reproduce the old behavior.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from scipy.special import expit, logit as _scipy_logit
from scipy.stats import entropy as _scipy_entropy


# ============================================================
# LOGGING
# ============================================================
# A library should not configure handlers for the host application; we attach a
# NullHandler so the engine never errors if the app hasn't set up logging. The
# deployer calls logging.basicConfig(...) and sets the level. INFO emits one
# line per eval; DEBUG additionally emits the pre-normalization regime scores
# and the per-term risk breakdown.

logger = logging.getLogger("sentinel")
logger.addHandler(logging.NullHandler())


# ============================================================
# NUMERICS  (stable, via scipy)
# ============================================================

def safe_logit(p: float) -> float:
    """logit with the domain clamped just inside (0,1)."""
    return float(_scipy_logit(min(max(p, 1e-9), 1.0 - 1e-9)))


def safe_expit(x: float) -> float:
    """Numerically stable sigmoid. No overflow for large |x|."""
    return float(expit(x))


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def shannon_entropy(dist: Dict["Regime", float]) -> float:
    """Natural-log entropy of a regime distribution (0 = certain, high = mixed)."""
    vals = np.array([v for v in dist.values() if v > 0.0], dtype=float)
    if vals.size == 0:
        return 0.0
    return float(_scipy_entropy(vals))  # scipy normalizes internally


# ============================================================
# ENUMS
# ============================================================

class PopulationType(Enum):
    NORMAL = "normal"
    SAVE = "save"
    FRAUD = "fraud"


class Result(Enum):
    NEUTRAL = "NEUTRAL"
    REGRESSIVE = "REGRESSIVE"
    RISK_INCREASING = "RISK_INCREASING"


class Regime(Enum):
    STABLE = "stable"
    SURGE = "surge"
    COGNITIVE_OVERLOAD = "cognitive_overload"
    PANIC = "panic"
    SATURATED = "saturated"
    ADVERSARIAL = "adversarial"


# Conditions under which falsification/learning must NOT occur.
# The synthetic fraud army is detection-only; anything tagged with it is excluded.
LEARNING_EXCLUSIONS = {"synthetic_fraud", "fraud_army", "detection_only", "contaminated"}


# ============================================================
# CONFIG  (every threshold/weight is tunable)
# ============================================================

@dataclass
class ResilienceConfig:
    # Lyapunov stability classification
    stability_stable_threshold: float = 1e-4
    stability_marginal_threshold: float = 1e-2
    # CONSERVATIVE DEFAULT: p90 of 1-week intraday variation (calibration gives
    # p90=0.086, p95=0.134). p90 trips REGRESSIVE sooner -> fewer missed
    # regressions at the cost of more false alarms. Tune UP after production data.
    energy_threshold: float = 0.086           # energy above -> REGRESSIVE

    # Risk verdict
    risk_threshold: float = 0.70              # CONSERVATIVE (was 0.75)
    risk_one_sided: bool = True               # True => zero change maps to zero risk

    # Risk scoring weights
    abandon_risk_weight: float = 2.0
    escalation_risk_weight: float = 1.5
    reentry_risk_weight: float = 1.5
    queue_risk_weight: float = 0.01

    # Entropy modulation of risk
    entropy_modifier_floor: float = 0.5
    entropy_modifier_sensitivity: float = 0.15

    # Hysteresis: incumbent regime gets a bonus to avoid flapping.
    # CONSERVATIVE DEFAULT 0.20 (was 0.15) -> less flapping. Tune after measuring
    # the field flap rate.
    regime_hysteresis: float = 0.20

    # Scale localization: regime detector expects metrics normalized against these.
    # AHT here is in seconds; queue is an absolute count. The intraday feed gives
    # AHT as an index around 1.0 — if you pass an index, set nominal_aht = 1.0.
    nominal_aht: float = 300.0
    nominal_queue: float = 50.0

    # Temporal: how strongly rising velocity escalates risk.
    # CONSERVATIVE DEFAULT 0.0 (DISABLED). Velocity-as-risk is speculative and was
    # never measured; leave off until production data justifies a value.
    velocity_risk_weight: float = 0.0

    # Confidence de-rating (alibi outputs)
    confidence_violation_penalty: float = 0.6   # multiply per out-of-bounds metric
    confidence_entropy_penalty: float = 0.4     # max fraction removed at full entropy
    confidence_untrusted_forecast: float = 0.8  # multiply if forecast not trusted

    # Regime detector weights
    regime_queue_surge_weight: float = 0.02
    regime_queue_saturated_weight: float = 0.03
    regime_response_time_weight: float = 0.01
    regime_queue_stable_weight: float = 0.01

    # Lyapunov per-metric weights
    stability_weights: Dict[str, float] = field(default_factory=lambda: {
        "abandon_rate": 5.0,
        "ivr_reentry_rate": 4.0,
        "escalation_rate": 4.0,
        "normalized_aht": 3.0,
        "containment": 3.0,
        "callback_rate": 2.0,
        "repeat_auth_rate": 2.0,
        "queue_depth": 5.0,
    })


# Provenance of every tunable: what each value is based on, so ops can tell
# guesswork from grounded settings. Surfaced in EvalResult.assumptions.
# Status legend: EMPIRICAL = derived from observed data; CONSERVATIVE = a safe
# placeholder biased toward caution; UNVALIDATED = inherited/assumed, no
# production evidence yet.
CALIBRATION_PROVENANCE: Dict[str, str] = {
    "energy_threshold":
        "CONSERVATIVE: p90 of 1-week intraday variation (180 cells). "
        "NOT validated on production borrower telemetry.",
    "risk_threshold":
        "CONSERVATIVE: placeholder 0.70, not empirically derived.",
    "regime_weights":
        "UNVALIDATED: from v3 config, rescaled for normalized metrics. "
        "Regime calls not yet checked against ops ground truth.",
    "regime_hysteresis":
        "UNVALIDATED: 0.20 chosen to limit flapping; flap rate not yet measured.",
    "velocity_risk_weight":
        "DISABLED (0.0): velocity-as-risk is speculative, never measured.",
    "forecast_trust_mae":
        "CONSERVATIVE: strict 0.05 MAE gate; loosen after measuring forecast "
        "quality on real metric series.",
    "empirical_baseline":
        "EMPIRICAL: abandon (vol-weighted 5.49%) and AHT index (99.6%) from the "
        "intraday feed. Other dimensions are starting assumptions.",
}


# ============================================================
# DOMAIN MODELS
# ============================================================

@dataclass
class RatePair:
    """Keep both the clamped probability and the raw pre-clamp value.
    The unclipped value preserves 'how far past the boundary' signal that a
    hard clamp would otherwise destroy."""
    unclipped: float
    p: float


@dataclass
class Metrics:
    containment: float = 0.0
    aht: float = 0.0
    callback_rate: float = 0.0
    abandon_rate: float = 0.0
    backoffice_trigger: float = 0.0
    determinism_index: float = 1.0
    repeat_auth_rate: float = 0.0
    ivr_reentry_rate: float = 0.0
    escalation_rate: float = 0.0          # named 'transfer_rate' in some variants
    short_disconnect_rate: float = 0.0
    queue_depth: float = 0.0
    # preserved unclipped signals
    unclipped_abandon_rate: Optional[float] = None
    unclipped_callback_rate: Optional[float] = None
    unclipped_ivr_reentry_rate: Optional[float] = None

    def as_vector(self) -> np.ndarray:
        return np.array([
            self.abandon_rate, self.ivr_reentry_rate, self.escalation_rate,
            self.aht, self.containment, self.callback_rate,
            self.repeat_auth_rate, self.queue_depth,
        ], dtype=float)

    # fields that must be probabilities in [0,1]
    _RATE_FIELDS = (
        "containment", "callback_rate", "abandon_rate", "backoffice_trigger",
        "determinism_index", "repeat_auth_rate", "ivr_reentry_rate",
        "escalation_rate", "short_disconnect_rate",
    )
    # fields that must be non-negative
    _NONNEG_FIELDS = ("aht", "queue_depth")

    def check_bounds(self) -> List[str]:
        """Return a list of human-readable bound violations (empty == clean).
        Also flags NaN/Inf, which would otherwise silently poison the math."""
        v: List[str] = []
        for f in self._RATE_FIELDS:
            x = getattr(self, f)
            if x is None:
                continue
            if not math.isfinite(x):
                v.append(f"{f}={x} is not finite")
            elif not (0.0 <= x <= 1.0):
                v.append(f"{f}={x:.4g} outside [0,1]")
        for f in self._NONNEG_FIELDS:
            x = getattr(self, f)
            if not math.isfinite(x):
                v.append(f"{f}={x} is not finite")
            elif x < 0.0:
                v.append(f"{f}={x:.4g} is negative")
        return v

    def sanitized(self) -> "Metrics":
        """A copy clamped into valid ranges so downstream math stays well-defined.
        NaN/Inf are replaced with safe values. Use together with check_bounds():
        validate for reporting, sanitize for computing."""
        def fix_rate(x):
            if x is None or not math.isfinite(x):
                return 0.0
            return min(1.0, max(0.0, x))

        def fix_nonneg(x):
            if not math.isfinite(x):
                return 0.0
            return max(0.0, x)

        changes = {f: fix_rate(getattr(self, f)) for f in self._RATE_FIELDS}
        changes.update({f: fix_nonneg(getattr(self, f)) for f in self._NONNEG_FIELDS})
        return dataclasses.replace(self, **changes)


@dataclass
class TemporalWindow:
    recent: List[Metrics] = field(default_factory=list)

    def push(self, m: Metrics, maxlen: int = 12) -> None:
        self.recent.append(m)
        if len(self.recent) > maxlen:
            self.recent.pop(0)

    def mean(self, attr: str) -> float:
        vals = [getattr(m, attr) for m in self.recent]
        return sum(vals) / len(vals) if vals else 0.0

    def velocity(self, attr: str) -> float:
        if len(self.recent) < 2:
            return 0.0
        return getattr(self.recent[-1], attr) - getattr(self.recent[-2], attr)


@dataclass
class RunContext:
    run_id: str
    timestamp: datetime
    contaminated: Optional[List[str]] = None
    last_regime: Optional[Regime] = None

    def learning_allowed(self) -> bool:
        if not self.contaminated:
            return True
        return not any(c in LEARNING_EXCLUSIONS for c in self.contaminated)

    def with_regime(self, regime: Regime) -> "RunContext":
        return RunContext(self.run_id, self.timestamp, self.contaminated, regime)


@dataclass
class RegimeProfile:
    scores: Dict[Regime, float]
    regime: Regime
    confidence: float
    entropy: float = 0.0


@dataclass
class EvalResult:
    population: PopulationType
    result: Result
    rationale: str
    dominant_regime: Regime
    regime_confidence: float
    regime_scores: Dict[str, float]
    regime_entropy: float
    lyapunov_energy: float
    risk_score: float
    learning_allowed: bool
    run_id: str
    timestamp: datetime
    # ---- alibi outputs: how much to trust this verdict, and why ----
    confidence: float = 1.0                # overall [0,1] after de-rating
    data_quality: str = "ok"               # "ok" or "degraded: <reasons>"
    bound_violations: List[str] = field(default_factory=list)
    assumptions: List[str] = field(default_factory=list)  # which knobs are guesswork

    def summary(self) -> str:
        flag = "" if self.data_quality == "ok" else f"  [{self.data_quality}]"
        return (f"{self.result.value} | regime={self.dominant_regime.value} "
                f"({self.regime_confidence:.0%}) | energy={self.lyapunov_energy:.4f} "
                f"| risk={self.risk_score:.3f} | confidence={self.confidence:.0%}{flag}")


# ============================================================
# REGIME DETECTION  (softmax-style, entropy via scipy)
# ============================================================

class RegimeDetector:
    def __init__(self, config: Optional[ResilienceConfig] = None):
        self.c = config or ResilienceConfig()

    def detect(self, m: Metrics, last_regime: Optional[Regime] = None) -> RegimeProfile:
        c = self.c
        # localize scale: rates stay 0-1; AHT and queue become indices near 1.0
        q_idx = m.queue_depth / max(c.nominal_queue, 1e-9)
        aht_idx = m.aht / max(c.nominal_aht, 1e-9)
        aht_excess = max(0.0, aht_idx - 1.0)   # only above-nominal handle time signals stress

        scores = {
            Regime.STABLE: max(0.0, 1.0 - (
                m.abandon_rate + m.escalation_rate + max(0.0, q_idx - 0.4) * 0.5)),
            Regime.SURGE: clamp(q_idx, 0.0, 3.0) * 0.4 + m.callback_rate,
            Regime.COGNITIVE_OVERLOAD: m.ivr_reentry_rate + m.repeat_auth_rate,
            Regime.PANIC: m.abandon_rate + m.escalation_rate,
            Regime.SATURATED: clamp(q_idx, 0.0, 3.0) * 0.5 + aht_excess * 1.0,
            Regime.ADVERSARIAL: 1.0 - m.determinism_index,
        }
        # hysteresis: nudge the incumbent regime to prevent rapid flapping
        if last_regime in scores:
            scores[last_regime] += c.regime_hysteresis

        if logger.isEnabledFor(logging.DEBUG):
            logger.debug("regime pre-norm scores: %s",
                         {k.value: round(v, 4) for k, v in scores.items()})

        total = sum(max(v, 0.0) for v in scores.values()) + 1e-9
        norm = {k: max(v, 0.0) / total for k, v in scores.items()}
        dominant = max(norm.items(), key=lambda kv: kv[1])[0]
        return RegimeProfile(norm, dominant, norm[dominant], shannon_entropy(norm))


# ============================================================
# LYAPUNOV STABILITY VERIFIER   V = Σ wᵢ (Δxᵢ)²
# ============================================================

class StabilityVerifier:
    # order must match Metrics.as_vector()
    _KEYS = ["abandon_rate", "ivr_reentry_rate", "escalation_rate", "normalized_aht",
             "containment", "callback_rate", "repeat_auth_rate", "queue_depth"]

    def __init__(self, config: Optional[ResilienceConfig] = None):
        self.c = config or ResilienceConfig()

    def energy(self, baseline: Metrics, current: Metrics) -> float:
        b, x = baseline, current
        deltas = np.array([
            x.abandon_rate - b.abandon_rate,
            x.ivr_reentry_rate - b.ivr_reentry_rate,
            x.escalation_rate - b.escalation_rate,
            (x.aht - b.aht) / (abs(b.aht) + 1e-9),     # normalized AHT delta
            -(x.containment - b.containment),           # containment drop is bad
            x.callback_rate - b.callback_rate,
            x.repeat_auth_rate - b.repeat_auth_rate,
            (x.queue_depth - b.queue_depth) / (abs(b.queue_depth) + 1.0),  # normalized
        ], dtype=float)
        w = np.array([self.c.stability_weights[k] for k in self._KEYS], dtype=float)
        return float(np.sum(w * deltas ** 2))

    def classify(self, energy: float) -> str:
        if energy <= self.c.stability_stable_threshold:
            return "stable"
        if energy <= self.c.stability_marginal_threshold:
            return "marginal"
        return "unstable"


# ============================================================
# ECHO-STATE RESERVOIR FORECASTER  (+ trust gate)
# ============================================================

class Reservoir:
    """Deterministic echo-state network, seeded reproducibly. Spectral radius is
    normalized at init to guarantee the echo-state property (no divergence)."""

    def __init__(self, seed: str, n: int = 64, n_inputs: int = 8,
                 spectral_radius: float = 0.9):
        rng = np.random.default_rng(
            int(hashlib.sha256(seed.encode()).hexdigest(), 16) % (2 ** 32))
        self.n, self.n_inputs = n, n_inputs
        self.W = rng.standard_normal((n, n)) * 0.05
        sr = np.max(np.abs(np.linalg.eigvals(self.W)))
        if sr > 0:
            self.W *= spectral_radius / sr
        self.Win = rng.standard_normal((n, n_inputs)) * 0.10
        self.state = np.zeros(n)
        self.Wout: Optional[np.ndarray] = None

    def step(self, u: np.ndarray) -> np.ndarray:
        self.state = np.tanh(self.W @ self.state + self.Win @ u)
        return self.state

    def train(self, X: np.ndarray, Y: np.ndarray, reg: float = 1e-3) -> None:
        states = []
        self.state = np.zeros(self.n)
        for row in X:
            states.append(self.step(row).copy())
        S = np.hstack([np.array(states), np.ones((len(states), 1))])
        self.Wout = np.linalg.pinv(S.T @ S + reg * np.eye(S.shape[1])) @ S.T @ Y

    def predict(self, u: np.ndarray, steps: int = 3) -> np.ndarray:
        if self.Wout is None:
            return np.tile(u, (steps, 1))
        s, out = self.state.copy(), []
        for _ in range(steps):
            s = np.tanh(self.W @ s + self.Win @ u)
            y = self.Wout @ np.concatenate([s, [1.0]])
            out.append(y)
            u = y[:self.n_inputs]
        return np.array(out)

    def bounded(self) -> bool:
        if self.Wout is None:
            return False
        test = self.predict(np.zeros(self.n_inputs), steps=2)
        return bool(np.all(np.isfinite(test)) and np.max(np.abs(test)) < 1e6)


@dataclass
class ForecastTracker:
    """Suppress forecasts once rolling MAE degrades, so governance is never
    steered by an untrustworthy prediction.

    CONSERVATIVE DEFAULTS: 0.05 MAE gate (was 0.15) and a 5-sample warm-up before
    a forecast is allowed to influence anything. Loosen only after measuring real
    forecast quality on production metric series."""
    errors: List[float] = field(default_factory=list)
    window: int = 20
    threshold: float = 0.05
    warmup: int = 5

    def record(self, predicted: np.ndarray, actual: np.ndarray) -> None:
        if predicted is None or actual is None or len(predicted) == 0 or len(actual) == 0:
            return
        mae = float(np.mean(np.abs(predicted[:len(actual)] - actual)))
        self.errors.append(mae)
        if len(self.errors) > self.window:
            self.errors.pop(0)

    def quality(self) -> float:
        return sum(self.errors) / len(self.errors) if self.errors else 0.0

    def trusted(self) -> bool:
        # During warm-up a forecast is NOT trusted (conservative): we'd rather
        # ignore an unproven forecast than let it steer governance.
        if len(self.errors) < self.warmup:
            return False
        return self.quality() < self.threshold


# ============================================================
# HASH-CHAINED AUDIT LEDGER
# ============================================================

@dataclass(frozen=True)
class Event:
    event_type: str
    run_id: str
    timestamp: datetime
    payload: Dict[str, Any]


class AuditLog:
    """Tamper-evident: each entry's hash chains the previous one."""

    def __init__(self):
        self._events: List[Event] = []
        self._hashes: List[str] = []

    def append(self, event: Event) -> str:
        prev = self._hashes[-1] if self._hashes else ""
        body = json.dumps({
            "type": event.event_type, "run_id": event.run_id,
            "ts": event.timestamp.isoformat(), "payload": event.payload, "prev": prev,
        }, sort_keys=True, default=str)
        h = hashlib.sha256(body.encode()).hexdigest()
        self._events.append(event)
        self._hashes.append(h)
        return h

    def verify(self) -> bool:
        prev = ""
        for ev, h in zip(self._events, self._hashes):
            body = json.dumps({
                "type": ev.event_type, "run_id": ev.run_id,
                "ts": ev.timestamp.isoformat(), "payload": ev.payload, "prev": prev,
            }, sort_keys=True, default=str)
            if hashlib.sha256(body.encode()).hexdigest() != h:
                return False
            prev = h
        return True

    def all(self) -> List[Event]:
        return list(self._events)


# ============================================================
# UNIFIED ENGINE
# ============================================================

class UnifiedResilienceEngine:
    def __init__(self, config: Optional[ResilienceConfig] = None,
                 audit: Optional[AuditLog] = None):
        self.c = config or ResilienceConfig()
        self.detector = RegimeDetector(self.c)
        self.verifier = StabilityVerifier(self.c)
        self.audit = audit or AuditLog()

    def risk_score(self, baseline: Metrics, current: Metrics,
                   profile: RegimeProfile, window: Optional[TemporalWindow] = None) -> float:
        c = self.c
        term_abandon = max(0.0, current.abandon_rate - baseline.abandon_rate) * c.abandon_risk_weight
        term_escal = max(0.0, current.escalation_rate - baseline.escalation_rate) * c.escalation_risk_weight
        term_reentry = max(0.0, current.ivr_reentry_rate - baseline.ivr_reentry_rate) * c.reentry_risk_weight
        term_queue = max(0.0, current.queue_depth - baseline.queue_depth) * c.queue_risk_weight
        raw = term_abandon + term_escal + term_reentry + term_queue

        # temporal: rising abandonment velocity adds pressure (disabled by default)
        term_velocity = 0.0
        if window is not None and c.velocity_risk_weight != 0.0:
            term_velocity = max(0.0, window.velocity("abandon_rate")) * c.velocity_risk_weight
            raw += term_velocity

        base = (2.0 * safe_expit(raw) - 1.0) if c.risk_one_sided else safe_expit(raw)
        modifier = max(c.entropy_modifier_floor,
                       1.0 - profile.entropy * c.entropy_modifier_sensitivity)
        score = clamp(base * modifier, 0.0, 1.0)

        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(
                "risk breakdown: abandon=%.4f escal=%.4f reentry=%.4f queue=%.4f "
                "velocity=%.4f raw=%.4f entropy_mod=%.4f -> risk=%.4f",
                term_abandon, term_escal, term_reentry, term_queue,
                term_velocity, raw, modifier, score)
        return score

    # ---- alibi helpers -----------------------------------------------------

    def _confidence(self, violations: List[str], entropy: float) -> float:
        c = self.c
        conf = 1.0
        for _ in violations:
            conf *= c.confidence_violation_penalty
        # high regime entropy (mixed/ambiguous call) lowers confidence
        ent_norm = entropy / math.log(len(Regime))  # 0..1
        conf *= (1.0 - c.confidence_entropy_penalty * min(1.0, ent_norm))
        return round(clamp(conf, 0.0, 1.0), 4)

    def _assumptions_for(self, verdict: Result) -> List[str]:
        keys = ["empirical_baseline"]  # always relevant
        if verdict == Result.REGRESSIVE:
            keys += ["energy_threshold", "regime_weights"]
        elif verdict == Result.RISK_INCREASING:
            keys += ["risk_threshold", "regime_weights"]
        else:
            keys += ["energy_threshold", "risk_threshold"]
        if self.c.regime_hysteresis:
            keys.append("regime_hysteresis")
        return [f"{k}: {CALIBRATION_PROVENANCE[k]}" for k in keys
                if k in CALIBRATION_PROVENANCE]

    def evaluate(self, baseline: Metrics, current: Metrics,
                 context: RunContext, population: PopulationType = PopulationType.NORMAL,
                 window: Optional[TemporalWindow] = None) -> EvalResult:

        # --- defensive bounds: report violations, compute on sanitized copies ---
        violations = baseline.check_bounds() + current.check_bounds()
        if violations:
            logger.warning("run %s: %d metric bound violation(s); de-rating "
                           "confidence and computing on clamped values: %s",
                           context.run_id, len(violations), "; ".join(violations))
        b_safe = baseline.sanitized()
        c_safe = current.sanitized()

        profile = self.detector.detect(c_safe, last_regime=context.last_regime)
        energy = self.verifier.energy(b_safe, c_safe)
        risk = self.risk_score(b_safe, c_safe, profile, window)

        if energy > self.c.energy_threshold:
            verdict = Result.REGRESSIVE
            rationale = (f"Lyapunov energy {energy:.4f} > {self.c.energy_threshold} "
                         f"(stability: {self.verifier.classify(energy)})")
        elif risk > self.c.risk_threshold:
            verdict = Result.RISK_INCREASING
            rationale = f"Risk {risk:.3f} > {self.c.risk_threshold} in regime {profile.regime.value}"
        else:
            verdict = Result.NEUTRAL
            rationale = (f"Stable: energy {energy:.4f}, risk {risk:.3f}, "
                         f"regime {profile.regime.value} ({profile.confidence:.0%})")

        confidence = self._confidence(violations, profile.entropy)
        data_quality = ("ok" if not violations
                        else f"degraded: {len(violations)} metric(s) out of bounds")

        res = EvalResult(
            population=population, result=verdict, rationale=rationale,
            dominant_regime=profile.regime, regime_confidence=profile.confidence,
            regime_scores={k.value: round(v, 4) for k, v in profile.scores.items()},
            regime_entropy=round(profile.entropy, 4),
            lyapunov_energy=round(energy, 6), risk_score=round(risk, 4),
            learning_allowed=context.learning_allowed(),
            run_id=context.run_id, timestamp=datetime.now(timezone.utc),
            confidence=confidence, data_quality=data_quality,
            bound_violations=violations, assumptions=self._assumptions_for(verdict),
        )

        # one INFO line per eval; rationale + assumptions at DEBUG
        logger.info("run=%s pop=%s -> %s | regime=%s(%.0f%%) energy=%.4f risk=%.3f "
                    "confidence=%.0f%% quality=%s learning=%s",
                    context.run_id, population.value, verdict.value,
                    profile.regime.value, profile.confidence * 100, energy, risk,
                    confidence * 100, data_quality, res.learning_allowed)
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug("run=%s rationale: %s", context.run_id, rationale)
            for a in res.assumptions:
                logger.debug("run=%s assumption: %s", context.run_id, a)

        self.audit.append(Event("evaluation", context.run_id, res.timestamp, {
            "population": population.value, "result": verdict.value,
            "regime": profile.regime.value, "risk": res.risk_score,
            "energy": res.lyapunov_energy, "confidence": confidence,
            "data_quality": data_quality, "learning_allowed": res.learning_allowed,
        }))
        return res


if __name__ == "__main__":
    # Turn on INFO logging so the per-eval line is visible in the demo.
    logging.basicConfig(level=logging.INFO,
                        format="  [%(levelname)s] %(name)s: %(message)s")

    eng = UnifiedResilienceEngine()
    base = Metrics(containment=0.82, aht=300, abandon_rate=0.055,
                   ivr_reentry_rate=0.10, escalation_rate=0.15,
                   determinism_index=0.95, queue_depth=12)

    print("\n=== 1. clean friction-increasing change ===")
    worse = Metrics(containment=0.70, aht=360, abandon_rate=0.18,
                    ivr_reentry_rate=0.28, escalation_rate=0.22,
                    determinism_index=0.6, queue_depth=95)
    r = eng.evaluate(base, worse, RunContext("demo-clean", datetime.now(timezone.utc)))
    print("  ->", r.summary())
    print("  assumptions surfaced to ops:")
    for a in r.assumptions:
        print("     -", a)

    print("\n=== 2. corrupted input (abandon_rate=1.7, aht=-5, NaN determinism) ===")
    print("     engine must NOT crash; it clamps, de-rates confidence, and flags it")
    bad = Metrics(containment=0.7, aht=-5, abandon_rate=1.7,
                  ivr_reentry_rate=0.2, escalation_rate=0.18,
                  determinism_index=float("nan"), queue_depth=40)
    r2 = eng.evaluate(base, bad, RunContext("demo-bad", datetime.now(timezone.utc)))
    print("  ->", r2.summary())
    print("  violations:", r2.bound_violations)

    print("\n=== 3. audit integrity ===")
    print("  audit verifies:", eng.audit.verify())

