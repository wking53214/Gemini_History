
from rgl.engine.governance import ResponseGovernanceLayer

def test_validation():
    rgl = ResponseGovernanceLayer()
    assert rgl.evaluate("System status nominal")["passed"] is True
