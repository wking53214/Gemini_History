
from rgl.validators.first_person import FirstPersonValidator

class ResponseGovernanceLayer:
    def __init__(self):
        self.validators = [FirstPersonValidator()]

    def evaluate(self, text:str):
        results = [v.validate(text) for v in self.validators]
        return {"passed": all(results), "checks": results}
