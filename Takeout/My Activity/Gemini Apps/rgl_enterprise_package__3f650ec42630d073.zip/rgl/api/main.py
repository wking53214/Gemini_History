
from fastapi import FastAPI
from pydantic import BaseModel
from rgl.engine.governance import ResponseGovernanceLayer

app = FastAPI(title="RGL")
rgl = ResponseGovernanceLayer()

class Request(BaseModel):
    text:str

@app.post("/validate")
def validate(req: Request):
    return rgl.evaluate(req.text)
