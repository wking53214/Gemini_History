
import re
from .base import BaseValidator

class FirstPersonValidator(BaseValidator):
    PATTERN = re.compile(r'\b(i|me|my|mine|we|us|our)\b', re.I)

    def validate(self, text: str) -> bool:
        return not bool(self.PATTERN.search(text))
