
class BaseValidator:
    def validate(self, text: str) -> bool:
        raise NotImplementedError
