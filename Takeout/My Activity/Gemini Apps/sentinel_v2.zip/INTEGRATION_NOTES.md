# Sentinel Consolidation — Integration Notes

## TL;DR

Your own Sentinel code is more advanced than the "ATS Governor" system built in
the earlier turns of this conversation. Rather than extend the weaker
reimplementation, I consolidated the strongest ideas from across your six
Sentinel variants into one engine, replaced hand-rolled numerics with the
correct library functions, fixed three real defects I found while reading, and
grounded the whole thing in your actual intraday telemetry.

Four files, all runnable and tested:

| File | What it is |
|---|---|
| `sentinel_unified.py` | The consolidated engine (Lyapunov + entropy + reservoir + audit) |
| `operational_data.py` | Loads your real intraday feed, derives baselines, calibrates thresholds |
| `evaluate_fraud_army.py` | The detection-only fraud-army gate, implemented per your governance doc |
| `test_properties.py` | Property-based tests (hypothesis) — 6 pass |

---

## 1. What exists where (lineage map)

You uploaded the same system at five maturity levels plus an adapter. They
overlap heavily (`sentinel.py` and `transported_sentinelv2.py` are near-identical;
several `.txt` files are byte-for-byte duplicates of the `.py`/`.md`):

```
Sentinel_v1_0.md ............ design intent
sentinel.py / v2 ............ full impl: borrower sim, audit ledger, behavior
                              models, temporal windows, learning charter
sentinel_api.py ............. productionized: FastAPI + JWT + Redis + locking,
                              echo-state reservoir forecaster, forecast trust gate
sentinel_ivr_production.py .. cleaner IVR: SAVE-wave detection, separate fraud path
Sentinel_v3_0.py ............ refactored core: externalized config, Lyapunov
                              stability, Shannon entropy, entropy-modulated risk
sentinel_adapter.py ......... thin gate into an external perceive_kernel
```

**What did not exist:** a single engine combining the v3 math, the v2
infrastructure, and the api forecaster — and none of it was tied to the real
`intraday_distribution_*` data. That gap is what this consolidation fills.

---

## 2. What's genuinely new / an upgrade — and where I took each piece

Merged into `sentinel_unified.py`:

- **Lyapunov stability energy** `V = Σ wᵢ(Δxᵢ)²` (from v3). A principled
  "how far has the system moved from baseline equilibrium" scalar. The earlier
  ATS Governor had nothing equivalent — it only had threshold rules.
- **Shannon entropy on the regime distribution** (from v3). Quantifies whether
  the regime call is confident or a genuinely mixed state.
- **Entropy-modulated risk** (from v3). Risk is suppressed when the regime is
  ambiguous, so you don't act hard on an uncertain read.
- **Externalized `ResilienceConfig`** (from v3). Every threshold/weight is a
  tunable field, not a magic number buried in code.
- **`RatePair` keeping clipped *and* unclipped rates** (from v2). The unclipped
  value preserves "how far past the boundary" signal that a hard clamp destroys.
- **`TemporalWindow.velocity`** (from v2), now wired into risk: rising
  abandonment velocity adds pressure. This is an upgrade *over* v3, which was
  point-in-time only.
- **`RunContext.learning_allowed()` charter** (from v2). The fraud army is
  detection-only; anything tagged contaminated is excluded from falsification.
- **Hash-chained `AuditLog`** (from v2), tamper-evident, with `verify()`.
- **Echo-state `Reservoir` + `ForecastTracker.trusted()`** (from the API). The
  reservoir normalizes its spectral radius to guarantee the echo-state property
  (no forecast divergence), and the tracker suppresses predictions once rolling
  error degrades, so governance is never steered by a bad forecast. This is the
  single best idea in your stack and it was buried in the Redis service.

What I deliberately **left in the API layer** (not core): FastAPI, JWT, Redis,
per-tenant locking. Those are deployment concerns; the engine shouldn't depend
on them. The reservoir was lifted out and made self-contained (numpy only).

---

## 3. Defects found while integrating (these are real)

1. **Lyapunov scale bug.** `queue_depth` deltas are on a 0–100 scale while every
   other metric is a 0–1 rate. Its squared term (weight 5) swamped the energy,
   making `energy_threshold` meaningless — any queue movement tripped REGRESSIVE.
   Fix: normalize the queue delta relative to baseline, same as AHT already was.

2. **Regime detector scale bug.** The detector multiplied raw `aht` (~300s) by a
   weight tuned for 0–1 inputs, so the SATURATED score was ~3.0 for *any* normal
   input and nearly everything classified as saturated. Fix: localize scale via
   `nominal_aht` / `nominal_queue` config and only let *above-nominal* AHT signal
   stress. After the fix all six regimes classify correctly (see the demo in
   `sentinel_unified.py __main__` and the scenario sweep).

3. **Risk floor bug in v3.** `risk = expit(raw) · modifier` with `raw ≥ 0` means
   `expit(raw) ∈ [0.5, 1)`, so a **no-op change scores ~0.25–0.5 risk**. Fix:
   `risk = (2·expit(raw) − 1) · modifier`, so zero change → zero risk. Guarded by
   `config.risk_one_sided` if you want to reproduce the old behavior.
   `test_properties.py` has a test that *documents* the old behavior so the
   regression can't silently come back.

---

## 4. Grounding in your real telemetry (this is the part that was missing)

`operational_data.py` loads the three intraday files with pandas and derives an
**empirical baseline** instead of hand-set numbers:

```
volume-weighted abandon = 5.487%      (was: a made-up 0.05)
mean AHT index          = 99.6%  → 299s
worst observed cell     = SAT 12:00, 37.8% abandon
```

It also **calibrates the energy threshold from real variation**. Computing the
Lyapunov energy of all 180 (day,time) cells against baseline gives:

```
median 0.0106 | p90 0.0861 | p95 0.1335 | p99 0.3067 | max 0.5226
```

The inherited v3 threshold of **0.10 sits between p90 and p95** — meaning ~7–10%
of *normal* traffic would falsely trip REGRESSIVE. Setting the threshold to the
p95 value (**0.1335**) holds the false-positive rate at 5% by construction. This
is a defensible, data-driven tuning the originals never had. (Caveat stated in
code: the feed only carries abandon + AHT, so calibration exercises those two
dimensions; recalibrate when you have reentry/queue/escalation history.)

---

## 5. The fraud army — implemented as your doc actually specifies

Your governance doc is explicit: the synthetic fraud army is a **negative
control**, detection-only, used to check whether an IVR change made the system
*more legible to hostile automation* (higher determinism, lower variance, faster
convergence). You don't "catch" it and there is no accuracy to report.

`evaluate_fraud_army.py` parses all 2000 entities, groups by the five intent
archetypes (population matches the doc's 40/20/15/15/10 split), and runs the
pre/post exposure comparison, emitting exactly the doc's reporting outputs
(per-archetype delta table + "Exposure increase detected" / "No material
exposure increase").

The result demonstrates the core tension cleanly:

- A change that **hardens the IVR** (smoother, more deterministic — *good for
  borrowers*) → **"Exposure increase detected"**, biggest jump on Temporal
  Consistency probing.
- A change adding **randomized verification** (mild borrower friction) → **"No
  material exposure increase"**, exposure drops across the board.

Same engine, opposite security verdicts — which is the entire point of running a
negative control before productionizing a change.

---

## 6. Honest accounting of the earlier "metrics"

The `EXECUTIVE_SUMMARY.md` / `MANIFEST.txt` produced earlier in this conversation
asserted figures like **"90%+ fraud detection accuracy," "Brier score 0.08,"
"95%+ regime accuracy," "P95 latency < 500ms," "99.9% uptime SLA."** None of
those were measured — they were written into documentation as if they were
results. That is the kind of thing worth removing before any of this goes in
front of NCH, a regulator, or an Anthropic Safeguards reviewer, because a single
fabricated number that gets caught discredits the real work.

Two of them can be made *real* with libraries already installed:

- A genuine detection number isn't applicable to the fraud army by design (it's
  a comparative gate, not a classifier). If you do want a labeled detector
  elsewhere, `sklearn.metrics.brier_score_loss` gives a real Brier score and
  `sklearn.ensemble.IsolationForest` a real anomaly detector — both measured on
  held-out data, not asserted.
- Latency/SLA are deployment facts; measure them with load tests against the
  actual API, don't state them up front.

---

## 7. Library recommendations (what would improve results, with concrete payoff)

Already used in the consolidation:

| Library | Replaces | Concrete payoff |
|---|---|---|
| `scipy.special.expit` / `logit` | hand-rolled `1/(1+exp(-x))` and the `±700` clamp | No overflow. `test_properties.py` proves the naive form raises `OverflowError` at x=−1000 where scipy returns 0.0. |
| `scipy.stats.entropy` | hand-rolled Shannon loop | Correct normalization + zero-handling in one call. |
| `numpy` | Python loops | Vectorized Lyapunov energy and the reservoir (your advanced files already used it; the earlier ATS Governor did not). |
| `pandas` (3.0) | hand-rolled CSV parsing | Clean intraday pivots and baseline derivation. Note: pandas 3.0 removed `applymap` — use `DataFrame.map` (your loaders will break on 3.0 otherwise). |
| `hypothesis` | example-only tests | Found the over-strict rounding assertion *and* would have caught the inv_logit overflow the old example tests missed. |

Worth adding next, in priority order:

| Library | Use | Why it fits |
|---|---|---|
| `scikit-learn` | `IsolationForest` for unsupervised anomaly scoring; `metrics` for real calibration | Lets any detection claim be *measured*. Does not violate the learning-exclusion charter — `IsolationForest` is unsupervised, it doesn't train on fraud labels. |
| `river` | online/streaming anomaly detection (`anomaly.HalfSpaceTrees`) | Detects drift on the live IVR stream without retraining, and stays charter-compliant (unsupervised). Natural complement to the reservoir. (Not currently installed.) |
| `filterpy` | Kalman filter on the metric trajectory | You already did a Kalman upgrade on OBSERVE; a Kalman smoother on the abandon/AHT series would pair with the reservoir for a smoothed-state + forecast combo. (Not currently installed.) |
| `pydantic` v2 | validate the core dataclasses at the boundary | Your `sentinel_api.py` already uses it for request models; extending it to `Metrics`/`Delta` gives runtime validation of external input. Optional — adds a dependency to the core. |
| `statsmodels` | seasonal decomposition of the intraday series | The MON 09:30 and SAT 12:00 spikes are strong day/time seasonality; STL decomposition would separate it from genuine anomalies before they hit the engine. |

---

## 8. How to run

```bash
cd sentinel_unified
python sentinel_unified.py        # engine self-test + a bad-change verdict
python operational_data.py        # empirical baseline + calibrated threshold
python evaluate_fraud_army.py     # detection-only gate, both scenarios
pip install pytest hypothesis --break-system-packages
pytest test_properties.py -q      # 6 property tests
```

The data paths in `__main__` point at `/mnt/user-data/uploads`; change them to
wherever you keep the feed.
