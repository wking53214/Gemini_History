"""
test_diagnostic.py — Locks the two-tier diagnostic engine.

Checks fall in four groups:
  DECOMPOSITION — the containment-honesty split (real vs fake) is correct.
  DISCOVERY      — the transparent scan finds the planted leaks; the tree's
                   candidates stay second-class and never self-certify.
  TIER DISCIPLINE — Findings and Candidates stay separate; nothing is client-ready
                   without Partner verdicts; the partner seam is intact.
  FAIRNESS       — the disparate-impact scan catches a planted protected disparity
                   AND does not false-alarm when there is none; protected
                   attributes are never optimization targets.
"""

from __future__ import annotations

import pytest

from reference_tree import build_reference_tree, run_harness
from caller_model import PopulationGenerator, PopulationConfig
from diagnostic_engine import DiagnosticEngine, BEHAVIORAL_KEYS, PROTECTED_KEYS
from diagnostic_types import Finding, Candidate, Verdict


def _run(n=10000, seed=11, plant_bias=False, bias_strength=0.35):
    cfg = PopulationConfig(n=n, seed=seed, plant_protected_bias=plant_bias,
                           protected_bias_strength=bias_strength)
    pop = PopulationGenerator(cfg).generate()
    tree = build_reference_tree()
    journeys = run_harness(pop, tree, seed=seed)
    observed = {c.caller_id: c.observed() for c in pop}
    return DiagnosticEngine().diagnose(journeys, observed), pop


# ── DECOMPOSITION ─────────────────────────────────────────────────────────────

def test_containment_decomposition_separates_real_from_fake():
    """Overall containment must split into real (resolved) + fake (unresolved),
    and fake must be a nonzero share of contained — the dashboard-hidden number."""
    report, _ = _run()
    o = report.overall
    assert o.contained == o.resolved + o.fake_contained, "decomposition does not add up"
    assert o.fake_contained > 0, "no fake containment detected"
    assert 0 < o.fake_share_of_contained < 1
    # containment must exceed true resolution (the gap exists)
    assert o.containment_rate > o.true_resolution_rate
    print(f"PASS: decomposition holds (containment {o.containment_rate:.1%} = "
          f"real {o.true_resolution_rate:.1%} + fake {o.fake_containment_rate:.1%}; "
          f"{o.fake_share_of_contained:.0%} of contained is fake)")


# ── DISCOVERY ─────────────────────────────────────────────────────────────────

def test_scan_finds_planted_reason_leak():
    """The transparent scan must surface the planted fraud/dispute leak as a
    Tier-1 finding."""
    report, _ = _run()
    desc = [f.segment.describe() for f in report.findings]
    # 'reason=fraud' should appear among findings (single or in a pair)
    assert any("reason=fraud" in d for d in desc), "scan missed the planted fraud leak"
    # and the worst finding should be a real, materially-below-overall leak
    worst = report.findings[0]
    assert worst.containment_gap_vs_overall < -0.05
    print(f"PASS: scan finds planted leak (worst: {worst.segment.describe()} "
          f"{worst.containment_gap_vs_overall*100:+.1f}pt)")


def test_scan_findings_are_legible_pairs_or_singles():
    """Every Tier-1 finding must be a single- or pairwise-attribute segment —
    transparent and human-checkable, by construction."""
    report, _ = _run()
    for f in report.findings:
        assert len(f.segment.constraints) <= 2, "finding deeper than pairwise leaked into Tier 1"
        assert f.method in ("scan:single", "scan:pairwise")
    print(f"PASS: all {len(report.findings)} findings are legible singles/pairs")


def test_tree_candidates_are_deep_interactions():
    """Tier-2 candidates, when present, must be depth>=3 interactions — i.e. things
    the pairwise scan could not have found."""
    report, _ = _run()
    for c in report.candidates:
        assert c.depth >= 3, "a shallow segment leaked into Tier 2 candidates"
        assert len(c.segment.constraints) >= 3
    print(f"PASS: all {len(report.candidates)} candidates are depth>=3 interactions")


# ── TIER DISCIPLINE ───────────────────────────────────────────────────────────

def test_findings_and_candidates_are_distinct_types():
    """Trust level is structural: findings are Findings, candidates are Candidates.
    They cannot be confused."""
    report, _ = _run()
    assert all(isinstance(f, Finding) for f in report.findings)
    assert all(isinstance(c, Candidate) for c in report.candidates)
    print("PASS: findings and candidates are distinct types (trust is structural)")


def test_no_candidate_is_client_ready_without_partner():
    """A candidate is client-ready ONLY when validation=REAL and fairness=CLEAN.
    Fresh from the engine, every candidate is UNASSESSED and NOT client-ready."""
    report, _ = _run()
    for c in report.candidates:
        assert c.validation_verdict == Verdict.UNASSESSED
        assert c.fairness_verdict in (Verdict.UNASSESSED, Verdict.FLAGGED)
        assert not c.client_ready, "a candidate self-certified as client-ready (must not!)"
    print(f"PASS: 0 of {len(report.candidates)} candidates are client-ready (Partner must validate)")


def test_partner_seam_present_on_every_result():
    """Every finding and candidate carries the two verdict slots the Partner fills."""
    report, _ = _run()
    for item in list(report.findings) + list(report.candidates):
        assert hasattr(item, "validation_verdict")
        assert hasattr(item, "fairness_verdict")
    print("PASS: partner seam (validation + fairness slots) present on every result")


def test_candidates_cross_checked_against_scan():
    """Each candidate records whether the transparent scan corroborates it — the
    cheap first ghost filter."""
    report, _ = _run()
    for c in report.candidates:
        assert c.corroborated_by_scan is not None
        if not c.corroborated_by_scan:
            assert any("ghost" in n.lower() for n in c.notes), \
                "uncorroborated candidate not labeled as ghost risk"
    print(f"PASS: all candidates cross-checked against scan "
          f"({sum(1 for c in report.candidates if c.corroborated_by_scan)} corroborated)")


# ── FAIRNESS ──────────────────────────────────────────────────────────────────

def test_disparate_impact_caught_when_planted():
    """With a planted protected disparity, the disparate-impact scan MUST flag it."""
    report, _ = _run(n=12000, plant_bias=True, bias_strength=0.35)
    di = [f for f in report.fairness_flags if "DISPARATE IMPACT" in f]
    assert len(di) >= 1, "planted disparate impact was NOT caught"
    assert any("protected_group=True" in f for f in di)
    print(f"PASS: planted disparate impact caught ({len(di)} flag(s))")


def test_no_disparate_impact_false_alarm():
    """Without a planted disparity, the disparate-impact scan must stay silent —
    no crying wolf on the protected attribute."""
    report, _ = _run(n=12000, plant_bias=False)
    di = [f for f in report.fairness_flags if "DISPARATE IMPACT" in f]
    assert len(di) == 0, f"false disparate-impact alarm: {di}"
    print("PASS: no disparate-impact false alarm when none is planted")


def test_protected_attributes_never_optimization_targets():
    """No finding or candidate offered as a leak may be DEFINED on a protected
    attribute. Protected attributes are flagged, never optimized on."""
    report, _ = _run(n=12000, plant_bias=True)
    for f in report.findings:
        if any(k in f.segment.constraints for k in PROTECTED_KEYS):
            assert f.fairness_verdict == Verdict.FLAGGED
            assert not f.safe_to_surface
    for c in report.candidates:
        if any(k in c.segment.constraints for k in PROTECTED_KEYS):
            assert c.fairness_verdict == Verdict.FLAGGED
            assert not c.client_ready
    print("PASS: protected attributes are flagged, never optimization targets")


def test_scan_only_optimizes_on_behavioral_keys():
    """The optimization scan must only produce segments on behavioral/contextual
    keys — never protected ones (those are handled by the disparate-impact scan)."""
    report, _ = _run(n=12000, plant_bias=True)
    for f in report.findings:
        for k in f.segment.constraints:
            assert k in BEHAVIORAL_KEYS, f"scan optimized on non-behavioral key '{k}'"
    print("PASS: optimization scan uses only behavioral/contextual keys")


# ── ROBUSTNESS ────────────────────────────────────────────────────────────────

def test_missing_observed_attributes_excluded_not_crashed():
    """Journeys with no observed attributes are excluded (and noted), not crashed."""
    report_full, pop = _run(n=2000)
    tree = build_reference_tree()
    journeys = run_harness(pop, tree, seed=11)
    # drop observed for half the callers
    observed = {c.caller_id: c.observed() for c in pop[:1000]}
    rep = DiagnosticEngine().diagnose(journeys, observed)
    assert any("had no observed attributes" in f for f in rep.fairness_flags)
    print("PASS: missing observed attributes excluded and noted, no crash")


def test_empty_journeys_no_crash():
    """An empty diagnostic run produces an empty report, not a crash."""
    rep = DiagnosticEngine().diagnose([], {})
    assert rep.overall.n == 0
    assert rep.findings == [] and rep.candidates == []
    print("PASS: empty journeys -> empty report, no crash")


if __name__ == "__main__":
    tests = [
        test_containment_decomposition_separates_real_from_fake,
        test_scan_finds_planted_reason_leak,
        test_scan_findings_are_legible_pairs_or_singles,
        test_tree_candidates_are_deep_interactions,
        test_findings_and_candidates_are_distinct_types,
        test_no_candidate_is_client_ready_without_partner,
        test_partner_seam_present_on_every_result,
        test_candidates_cross_checked_against_scan,
        test_disparate_impact_caught_when_planted,
        test_no_disparate_impact_false_alarm,
        test_protected_attributes_never_optimization_targets,
        test_scan_only_optimizes_on_behavioral_keys,
        test_missing_observed_attributes_excluded_not_crashed,
        test_empty_journeys_no_crash,
    ]
    print("=" * 70)
    failures = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            failures += 1
            print(f"FAIL: {t.__name__}: {e}")
    print("=" * 70)
    print(f"{'ALL ' + str(len(tests)) + ' DIAGNOSTIC TESTS PASSED' if not failures else str(failures) + ' FAILED'}")
