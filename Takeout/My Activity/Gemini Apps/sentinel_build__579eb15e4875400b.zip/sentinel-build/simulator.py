"""
simulator.py — Measure the whole-population effect of a proposed IVR change,
honestly: net AND distribution, so the landmine is visible before anything ships.

This is the piece that makes the thesis ACTIONABLE without making it dangerous.
The diagnostic engine finds where containment leaks; the simulator answers "if I
change the tree THIS way, what happens to EVERYONE?" — including the segment a
change might hurt.

THE CONTROLLED COMPARISON
-------------------------
Same population, baseline tree vs variant tree, deterministic traversal (each
caller's RNG is seeded by their id, so a given caller behaves identically across
trees). Any difference in outcome is therefore attributable to the STRUCTURE, not
to noise — which is the only way a measured delta means anything.

WHY THE NET NUMBER IS NEVER ENOUGH
----------------------------------
The danger is a change that lifts containment on average while wrecking a segment:
"+10% on 25% of callers, but 5% now go agent-only." A simulator that reported only
the net would say "ship it." This one decomposes the effect across the segments the
diagnostic flagged (and the standard behavioral cuts), and surfaces any HARMED
segment at the top level. A net gain with a harmed segment is explicitly NOT a
clean win.

WHAT A "CHANGE" IS
------------------
A change is a function `IVRTree -> IVRTree` that returns a modified CLONE (the tree
module's `reorder_menu` / `move_option_to_end` already do this without mutating the
original). The simulator never mutates the baseline. Helpers below wrap the common
re-sequencing moves so a caller can describe a change declaratively.

THE HONESTY BOUNDARY
--------------------
The simulator MEASURES a proposed change. It does not SEARCH for changes (that is
the optional auto-optimizer, deliberately deferred — an optimizer chasing a net
number is exactly how you find the landmine). And its output is a measurement, not
a recommendation: turning a clean measured win into a client-facing prescription,
with calibrated confidence, is the prescription layer's job. Each boundary keeps
the next component honest.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from ivr_tree import IVRTree, Outcome
from caller_model import Caller
from traversal import Journey, TraversalEngine
from simulation_types import (
    OutcomeMix, SegmentEffect, SimulationResult, SEGMENT_HARM_THRESHOLD,
)

# A change transforms a tree into a modified clone. By contract it must NOT mutate
# the input (the tree helpers honor this).
TreeChange = Callable[[IVRTree], IVRTree]


def _mix(journeys: Sequence[Journey]) -> OutcomeMix:
    n = len(journeys)
    return OutcomeMix(
        n=n,
        contained=sum(1 for j in journeys if j.contained),
        resolved=sum(1 for j in journeys if j.truly_resolved),
        fake_contained=sum(1 for j in journeys if j.outcome is Outcome.CONTAINED_UNRESOLVED),
        reached_agent=sum(1 for j in journeys if j.outcome is Outcome.AGENT),
        poundout=sum(1 for j in journeys if j.outcome is Outcome.POUNDOUT),
        hangup=sum(1 for j in journeys if j.outcome is Outcome.HANGUP),
    )


class Simulator:
    """Runs controlled before/after comparisons of IVR changes on a population."""

    def __init__(self, seed: int = 11,
                 segment_keys: Sequence[str] = ("reason", "channel", "product"),
                 min_segment_n: int = 150):
        """
        seed         : traversal seed; MUST be identical for baseline and variant
                       so the comparison is controlled.
        segment_keys : the observed attributes to decompose the effect across.
                       These are the cuts a harmed segment could hide in.
        min_segment_n: segments smaller than this are not separately judged for
                       harm (too small to trust the delta).
        """
        self.seed = seed
        self.segment_keys = tuple(segment_keys)
        self.min_segment_n = min_segment_n

    # ── core: measure one change ──────────────────────────────────────────────

    def measure(self, baseline_tree: IVRTree, change: TreeChange,
                callers: Sequence[Caller],
                observed_by_id: Dict[str, Dict[str, object]],
                change_description: str = "proposed change") -> SimulationResult:
        """Run the population through baseline and through the changed tree, and
        return the full distributional effect."""
        assumptions = [
            "Controlled comparison: same population, same seed; difference is "
            "attributable to structure, not noise.",
            "Effect measured on BOTH containment and true resolution (a change can "
            "raise containment by raising FAKE containment).",
            "A net gain with a harmed segment is NOT a clean win.",
            f"Segment harm threshold = {SEGMENT_HARM_THRESHOLD:.0%} (illustrative).",
        ]
        engine = TraversalEngine(seed=self.seed)

        variant_tree = change(baseline_tree)
        # safety: the change must not have mutated the baseline
        if variant_tree is baseline_tree:
            raise ValueError("change returned the same tree object; it must return a modified clone")

        base_journeys = [engine.run(c, baseline_tree) for c in callers]
        var_journeys = [engine.run(c, variant_tree) for c in callers]

        base_by_id = {j.caller_id: j for j in base_journeys}
        var_by_id = {j.caller_id: j for j in var_journeys}

        overall_base = _mix(base_journeys)
        overall_var = _mix(var_journeys)

        result = SimulationResult(
            change_description=change_description,
            population_n=len(callers),
            net_containment_delta=round(overall_var.containment_rate - overall_base.containment_rate, 4),
            net_true_resolution_delta=round(overall_var.true_resolution_rate - overall_base.true_resolution_rate, 4),
            net_fake_containment_delta=round(overall_var.fake_containment_rate - overall_base.fake_containment_rate, 4),
            net_agent_delta=round(overall_var.agent_rate - overall_base.agent_rate, 4),
            overall_baseline=overall_base,
            overall_variant=overall_var,
            assumptions=assumptions,
        )

        # decompose across segments
        result.segment_effects = self._segment_effects(
            callers, observed_by_id, base_by_id, var_by_id)
        result.harmful_segments = [s for s in result.segment_effects if s.is_harmed]
        result.helped_segments = [s for s in result.segment_effects if s.is_helped]
        if result.harmful_segments:
            # worst harm = the segment whose containment fell most (or agent rose most)
            result.worst_harm = min(
                result.harmful_segments,
                key=lambda s: min(s.containment_delta, -s.agent_delta))

        result.verdict = self._verdict(result)
        return result

    def _segment_effects(self, callers, observed_by_id, base_by_id, var_by_id) -> List[SegmentEffect]:
        effects: List[SegmentEffect] = []
        for key in self.segment_keys:
            groups: Dict[object, List[str]] = defaultdict(list)
            for c in callers:
                obs = observed_by_id.get(c.caller_id)
                if obs is not None and key in obs:
                    groups[obs[key]].append(c.caller_id)
            for val, ids in groups.items():
                if len(ids) < self.min_segment_n:
                    continue
                base_js = [base_by_id[i] for i in ids if i in base_by_id]
                var_js = [var_by_id[i] for i in ids if i in var_by_id]
                bm, vm = _mix(base_js), _mix(var_js)
                effects.append(SegmentEffect(
                    label=f"{key}={val}",
                    n=len(ids),
                    containment_delta=round(vm.containment_rate - bm.containment_rate, 4),
                    true_resolution_delta=round(vm.true_resolution_rate - bm.true_resolution_rate, 4),
                    fake_containment_delta=round(vm.fake_containment_rate - bm.fake_containment_rate, 4),
                    agent_delta=round(vm.agent_rate - bm.agent_rate, 4),
                    baseline=bm, variant=vm,
                ))
        # sort worst-hit first so harm is at the top of any listing
        effects.sort(key=lambda s: s.containment_delta)
        return effects

    def _verdict(self, r: SimulationResult) -> str:
        if r.net_containment_delta <= 0 and r.net_true_resolution_delta <= 0:
            return "NO IMPROVEMENT — net containment and resolution did not rise."
        if r.net_fake_containment_delta > SEGMENT_HARM_THRESHOLD:
            return ("FALSE WIN — containment rose largely by trapping more callers in "
                    "unresolved self-service (fake containment up). Not a real gain.")
        if r.harmful_segments:
            return (f"LANDMINE — net gain of {r.net_containment_delta*100:+.1f}pt, but "
                    f"{len(r.harmful_segments)} segment(s) are harmed (worst: "
                    f"{r.worst_harm.label}, {r.worst_harm.containment_delta*100:+.1f}pt "
                    f"containment / {r.worst_harm.agent_delta*100:+.1f}pt agent). "
                    f"Do NOT ship without addressing the harmed segment.")
        if r.is_clean_win:
            return (f"CLEAN WIN — net +{r.net_containment_delta*100:.1f}pt containment and "
                    f"+{r.net_true_resolution_delta*100:.1f}pt true resolution, no segment harmed.")
        return "MARGINAL — a small or mixed effect; weigh against implementation cost."

    # ── convenience: measure several changes and rank them ────────────────────

    def compare(self, baseline_tree: IVRTree,
                changes: List[Tuple[str, TreeChange]],
                callers: Sequence[Caller],
                observed_by_id: Dict[str, Dict[str, object]]) -> List[SimulationResult]:
        """Measure several proposed changes; return results sorted by net
        containment gain, BUT clean wins ranked above landmines regardless of net
        (a harmed segment demotes a change). Honesty in the ranking itself."""
        results = [self.measure(baseline_tree, ch, callers, observed_by_id, desc)
                   for desc, ch in changes]
        # sort: clean wins first (by net desc), then everything else (by net desc).
        # A landmine never outranks a clean win even if its net is larger.
        results.sort(key=lambda r: (not r.is_clean_win, -r.net_containment_delta))
        return results


# ── declarative change helpers (each returns a TreeChange that clones) ─────────

def push_option_last(node_id: str, target_id: str) -> TreeChange:
    """A change that moves one option to the end of a menu (e.g. agent option)."""
    def _change(tree: IVRTree) -> IVRTree:
        return tree.move_option_to_end(node_id, target_id)
    return _change


def reorder_menu(node_id: str, new_order: List[str]) -> TreeChange:
    """A change that permutes a menu's options into an explicit order."""
    def _change(tree: IVRTree) -> IVRTree:
        return tree.reorder_menu(node_id, new_order)
    return _change


def lead_with(node_id: str, target_id: str) -> TreeChange:
    """A change that moves one option to the FRONT of a menu (lead with the
    high-frequency self-serve option)."""
    def _change(tree: IVRTree) -> IVRTree:
        order = [target_id] + [o.target_id for o in tree.node(node_id).options
                               if o.target_id != target_id]
        return tree.reorder_menu(node_id, order)
    return _change
