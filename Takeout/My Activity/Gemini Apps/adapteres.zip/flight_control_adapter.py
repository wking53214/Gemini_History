"""
flight_control_adapter.py

Flight control system of a crewed space shuttle. Human-rated, so thresholds are
conservative and faults score heavily.

Distinctive parameters: an attitude quaternion (a CONSTRAINED 4-vector -- unit
norm; drift signals an estimator fault), redundancy/voting health (an integer
channel count -- loss of a majority is critical), and pilot/control-induced
oscillation (a growing closed-loop oscillation in tracking error).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import numpy as np

import dynamics_core as core


@dataclass
class FlightControlSnapshot:
    quaternion: Tuple[float, float, float, float]     # (w, x, y, z) attitude estimate
    body_rates_dps: Tuple[float, float, float]        # p, q, r (deg/s)
    tracking_error_deg: float
    effector_command: float                           # commanded deflection/thrust, fraction
    rate_limit_dps: float = 20.0
    tracking_error_limit_deg: float = 5.0
    effector_limit: float = 1.0
    quaternion_norm_tol: float = 1e-2
    pio_amplitude_floor_deg: float = 1.0
    redundant_channels_total: int = 4
    redundant_channels_agreeing: int = 4
    context: Optional[Dict[str, Any]] = None          # tracking_error_history (deg)


def flight_control_adapter(snapshot: FlightControlSnapshot) -> core.RiskOutput:
    qn = math.sqrt(sum(c * c for c in snapshot.quaternion))
    qnorm_err = abs(qn - 1.0)
    estimator_fault = qnorm_err > snapshot.quaternion_norm_tol

    max_rate = max(abs(r) for r in snapshot.body_rates_dps)
    rate_exceed = max_rate > snapshot.rate_limit_dps

    tracking_exceed = abs(snapshot.tracking_error_deg) > snapshot.tracking_error_limit_deg
    effector_saturated = abs(snapshot.effector_command) >= snapshot.effector_limit

    total = max(1, snapshot.redundant_channels_total)
    agreeing = snapshot.redundant_channels_agreeing
    majority_needed = total // 2 + 1
    majority_lost = agreeing < majority_needed
    redundancy_degraded = (not majority_lost) and agreeing < total

    ctx = snapshot.context or {}
    err_hist = np.asarray(ctx.get("tracking_error_history", []), dtype=float)
    pio_growth = 0.0
    pio = False
    if len(err_hist) >= 8:
        amplitude = float(np.std(err_hist))
        pio_growth = core.oscillation_growth_rate(err_hist)
        pio = bool(pio_growth > 0.0 and amplitude > snapshot.pio_amplitude_floor_deg)

    score = 0.0
    score += 4.0 if rate_exceed else 0.0
    score += 4.0 if tracking_exceed else 0.0
    score += 3.0 if effector_saturated else 0.0
    score += 5.0 if estimator_fault else 0.0          # attitude state untrustworthy
    score += 5.0 if pio else 0.0                      # closed-loop instability
    score += 3.0 if redundancy_degraded else 0.0
    score += 8.0 if majority_lost else 0.0            # no fault-tolerant vote -> critical

    return core.RiskOutput(
        adapter_name="flight_control",
        metric_score=float(score),
        confidence_rating=0.98,
        meta_payload={
            "quaternion_norm_error": qnorm_err,
            "estimator_fault": estimator_fault,
            "max_body_rate_dps": max_rate,
            "rate_exceed": rate_exceed,
            "tracking_exceed": tracking_exceed,
            "effector_saturated": effector_saturated,
            "channels_agreeing": agreeing,
            "channels_total": total,
            "redundancy_degraded": redundancy_degraded,
            "majority_lost": majority_lost,
            "pio_growth_rate": pio_growth,
            "pilot_induced_oscillation": pio,
        },
    )
