"""
dynamics_core.py

Shared, domain-agnostic numerical core for the adapter family, plus the
canonical RiskOutput contract every adapter returns.

Everything in here operates on REAL-VALUED signals in a metric space
(embeddings, derivatives, phases, Lyapunov exponents). Domains whose parameter
type is not a continuous metric signal (e.g. symbolic sequences) deliberately
do NOT import the math below -- they only share RiskOutput for output
uniformity.

Certify/attest this module once (record CORE_VERSION + a content hash in the
audit ledger); each domain adapter is then a thin layer whose review scope is
"core vN + this adapter". A regime that requires a frozen in-tree copy can
still vendor this file per-domain.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pywt
from scipy.spatial import KDTree

CORE_VERSION = "1.0.0"


# ---------------------------------------------------------------------------
# Canonical output contract
# ---------------------------------------------------------------------------


@dataclass
class RiskOutput:
    adapter_name: str
    metric_score: float
    confidence_rating: float
    meta_payload: Dict[str, Any] = field(default_factory=dict)
    core_version: str = CORE_VERSION


# ---------------------------------------------------------------------------
# Continuous-signal primitives
# ---------------------------------------------------------------------------


def phase_space_embedding(stream: np.ndarray, dt: float = 0.01) -> np.ndarray:
    """Augment a 1-D signal with its 1st/2nd derivatives: (value, velocity, accel)."""
    stream = np.asarray(stream, dtype=float)
    if len(stream) < 3:
        z = np.zeros_like(stream)
        return np.column_stack((stream, z, z))
    velocity = np.gradient(stream, dt)
    acceleration = np.gradient(velocity, dt)
    return np.column_stack((stream, velocity, acceleration))


def estimate_embedding_lag_dwt(signal: np.ndarray) -> int:
    """Estimate a time-delay embedding lag from DWT detail-band zero crossings."""
    signal = np.asarray(signal, dtype=float)
    if len(signal) < 8:
        return 1
    wavelet = pywt.Wavelet("db4")
    max_level = pywt.dwt_max_level(len(signal), wavelet.dec_len)
    if max_level < 1:
        return 1
    coeffs = pywt.wavedec(signal, wavelet, level=min(2, max_level))
    detail = coeffs[1]
    zero_crossings = np.where(np.diff(np.sign(detail)))[0]
    if len(zero_crossings) < 2:
        return 2
    return max(1, int(np.mean(np.diff(zero_crossings))))


def phase_coherence(phase_a: np.ndarray, phase_b: np.ndarray) -> np.ndarray:
    """Per-sample Kuramoto order parameter between two phase signals (0..1)."""
    combined = np.column_stack((phase_a, phase_b))
    return np.abs(np.mean(np.exp(1j * combined), axis=1))


def phase_locking_value(relative_phase: np.ndarray) -> float:
    """Constancy of a relative phase over the window (1 = perfectly locked)."""
    rp = np.asarray(relative_phase, dtype=float)
    if len(rp) == 0:
        return 0.0
    return float(np.abs(np.mean(np.exp(1j * rp))))


def linear_trend(series: np.ndarray) -> Tuple[float, float, float]:
    """Return (slope_per_sample, residual_std, total_change_over_window)."""
    s = np.asarray(series, dtype=float)
    n = len(s)
    if n < 3:
        return 0.0, 0.0, 0.0
    x = np.arange(n, dtype=float)
    slope, intercept = np.polyfit(x, s, 1)
    residual = s - (slope * x + intercept)
    return float(slope), float(np.std(residual)), float(abs(slope) * (n - 1))


def oscillation_growth_rate(series: np.ndarray) -> float:
    """log(RMS of 2nd half / RMS of 1st half) of the de-meaned signal.

    > 0  -> oscillation amplitude is GROWING (small-signal instability).
    <= 0 -> bounded or decaying.
    """
    s = np.asarray(series, dtype=float)
    n = len(s)
    if n < 8:
        return 0.0
    s = s - np.mean(s)
    h = n // 2
    early = math.sqrt(float(np.mean(s[:h] ** 2)))
    late = math.sqrt(float(np.mean(s[h:] ** 2)))
    if early <= 1e-12 or late <= 1e-12:
        return 0.0
    return float(math.log(late / early))


def max_cross_correlation(a: np.ndarray, b: np.ndarray,
                          max_lag: Optional[int] = None) -> Tuple[float, int]:
    """Peak |normalized cross-correlation| between two signals and its lag.

    ~0   -> independent.
    ~1   -> one is (a lagged copy of) the other == coordinated.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    n = min(len(a), len(b))
    if n < 4:
        return 0.0, 0
    a = a[-n:] - np.mean(a[-n:])
    b = b[-n:] - np.mean(b[-n:])
    sa, sb = np.std(a), np.std(b)
    if sa < 1e-12 or sb < 1e-12:
        return 0.0, 0
    a, b = a / sa, b / sb
    if max_lag is None:
        max_lag = min(n // 2, 32)

    best_abs, best_lag = 0.0, 0
    for lag in range(-max_lag, max_lag + 1):
        if lag >= 0:
            x, y = a[lag:], b[:n - lag]
        else:
            x, y = a[:n + lag], b[-lag:]
        m = len(x)
        if m < 3:
            continue
        corr = float(np.dot(x, y) / m)
        if abs(corr) > best_abs:
            best_abs, best_lag = abs(corr), lag
    return best_abs, best_lag


def largest_lyapunov_exponent(series: np.ndarray, lag: int,
                              embedding_dim: int = 3,
                              max_horizon: Optional[int] = None) -> float:
    """Rosenstein-style largest Lyapunov exponent (per sample).

    For every embedded point take its nearest temporally-separated neighbour,
    track how the pair separates over `max_horizon` forward steps, average
    ln(separation) across pairs, and return the slope of that divergence curve.

    Positive  -> trajectories diverge.   ~Zero/neg -> bounded.
    NOTE: noise-sensitive on short windows; treat as an indicator, not a gate.
    """
    series = np.asarray(series, dtype=float)
    n = len(series)
    if lag < 1 or n < (embedding_dim - 1) * lag + 20:
        return 0.0

    rows = n - (embedding_dim - 1) * lag
    stride = series.strides[0]
    vectors = np.lib.stride_tricks.as_strided(
        series, shape=(rows, embedding_dim), strides=(stride, lag * stride)
    ).copy()
    m = len(vectors)

    if max_horizon is None:
        max_horizon = min(20, m // 4)
    if max_horizon < 2:
        return 0.0

    tree = KDTree(vectors)
    pairs = []
    for i in range(m):
        k = min(embedding_dim + 5, m)
        _, idx = tree.query(vectors[i], k=k)
        neighbour = next((int(j) for j in np.atleast_1d(idx) if abs(int(j) - i) > lag), None)
        if neighbour is not None:
            pairs.append((i, neighbour))
    if len(pairs) < 5:
        return 0.0

    log_div = np.zeros(max_horizon)
    counts = np.zeros(max_horizon)
    for i, j in pairs:
        for k in range(max_horizon):
            if i + k < m and j + k < m:
                d = np.linalg.norm(vectors[i + k] - vectors[j + k])
                if d > 0.0:
                    log_div[k] += math.log(d)
                    counts[k] += 1.0

    valid = counts > 0
    if valid.sum() < 2:
        return 0.0
    curve = log_div[valid] / counts[valid]
    steps = np.arange(max_horizon)[valid].astype(float)
    return float(np.polyfit(steps, curve, 1)[0])
