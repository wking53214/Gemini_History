"""
dna_storage_adapter.py

A DNA digital-data-storage channel: bits are encoded into synthesized
nucleotide strands, stored, then sequenced back.

THE NOVEL PARAMETER TYPE (the point of this adapter): a discrete symbolic
sequence over a finite alphabet {A, C, G, T}. Its natural distance is the
edit (Levenshtein) distance -- a combinatorial, NON-Euclidean quantity. There
is no derivative, no phase, no metric embedding, so none of the continuous
dynamical-core primitives (embedding, Lyapunov, FFT, cross-correlation) apply.
This module therefore imports only the shared RiskOutput contract and brings
its own symbolic operators.

Distinctive signals: edit distance to the reference vs the error-correcting
code's correction capacity (uncorrectable == data loss), GC-content drift
(storage-medium bias), and homopolymer run length (synthesis/sequencing error
hotspot).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from dynamics_core import RiskOutput   # output contract ONLY -- no dynamical math

_ALPHABET = frozenset("ACGT")


def _levenshtein(a: str, b: str) -> int:
    """Edit distance (substitutions + insertions + deletions). O(len(a)*len(b))."""
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        cur = [i]
        for j, cb in enumerate(b, start=1):
            cost = 0 if ca == cb else 1
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost))
        prev = cur
    return prev[-1]


def _gc_content(seq: str) -> float:
    if not seq:
        return 0.0
    gc = sum(1 for ch in seq if ch in ("G", "C"))
    return gc / len(seq)


def _max_homopolymer_run(seq: str) -> int:
    best = run = 0
    last = ""
    for ch in seq:
        run = run + 1 if ch == last else 1
        last = ch
        best = max(best, run)
    return best


@dataclass
class DnaStorageSnapshot:
    read_sequence: str
    reference_sequence: str
    ecc_correction_capacity: int       # max edits the error-correcting code can repair
    gc_low: float = 0.40
    gc_high: float = 0.60
    max_homopolymer_run: int = 4        # longer runs are error-prone
    context: Optional[Dict[str, Any]] = None


def dna_storage_adapter(snapshot: DnaStorageSnapshot) -> RiskOutput:
    read = snapshot.read_sequence.upper()
    invalid_symbols = sorted(set(read) - _ALPHABET)
    corrupt_alphabet = len(invalid_symbols) > 0

    edits = _levenshtein(read, snapshot.reference_sequence.upper())
    uncorrectable = edits > snapshot.ecc_correction_capacity      # == data loss

    gc = _gc_content(read)
    gc_drift = gc < snapshot.gc_low or gc > snapshot.gc_high

    longest_run = _max_homopolymer_run(read)
    homopolymer_hotspot = longest_run > snapshot.max_homopolymer_run

    score = 0.0
    score += 10.0 if corrupt_alphabet else 0.0       # non-nucleotide symbol -> channel broken
    score += 8.0 if uncorrectable else 0.0           # beyond ECC -> unrecoverable data loss
    score += 3.0 if gc_drift else 0.0
    score += 3.0 if homopolymer_hotspot else 0.0

    return RiskOutput(
        adapter_name="dna_storage",
        metric_score=float(score),
        confidence_rating=0.96,
        meta_payload={
            "edit_distance": edits,
            "ecc_correction_capacity": snapshot.ecc_correction_capacity,
            "uncorrectable": uncorrectable,
            "invalid_symbols": invalid_symbols,
            "gc_content": gc,
            "gc_drift": gc_drift,
            "max_homopolymer_run": longest_run,
            "homopolymer_hotspot": homopolymer_hotspot,
        },
    )
