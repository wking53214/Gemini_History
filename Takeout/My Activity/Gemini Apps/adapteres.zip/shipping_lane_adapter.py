"""
shipping_lane_adapter.py

Global commodity distribution over shipping lanes / chokepoints, hardened
against TWO adversarial state actors who each manipulate the system and
PERIODICALLY coordinate.

Distinctive parameter type: multi-agent adversarial coupling. Beyond the usual
market-deviation check, this adapter attributes activity to each actor and then
measures the cross-correlation between their interference streams. The
dangerous state is not either actor acting alone -- it is the two acting in
concert (one stream a lagged copy of the other). Because coordination is
evaluated per window, the collusion flag turns on and off across successive
snapshots, which is exactly how "periodically work together" presents.

Three regimes are reported: quiet / independent_manipulation / coordinated.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

import dynamics_core as core


@dataclass
class ShippingSnapshot:
    lane_throughput: float            # e.g. TEU/day through a chokepoint
    baseline_throughput: float
    price: float
    baseline_price: float
    throughput_tolerance_frac: float = 0.15   # +/-15% counts as normal variation
    price_tolerance_frac: float = 0.10
    actor_activity_floor: float = 0.05        # RMS of an actor's stream above this == active
    coordination_floor: float = 0.6           # peak cross-corr above this == coordinated
    context: Optional[Dict[str, Any]] = None
    # context:
    #   actor_a_signal_history : actor A's attributed perturbation stream (fractional)
    #   actor_b_signal_history : actor B's attributed perturbation stream (fractional)


def _frac_dev(value: float, baseline: float) -> float:
    if baseline == 0:
        return 0.0
    return abs(value - baseline) / abs(baseline)


def shipping_lane_adapter(snapshot: ShippingSnapshot) -> core.RiskOutput:
    tput_dev = _frac_dev(snapshot.lane_throughput, snapshot.baseline_throughput)
    price_dev = _frac_dev(snapshot.price, snapshot.baseline_price)
    tput_disrupted = tput_dev > snapshot.throughput_tolerance_frac
    price_manipulated = price_dev > snapshot.price_tolerance_frac

    ctx = snapshot.context or {}
    a = np.asarray(ctx.get("actor_a_signal_history", []), dtype=float)
    b = np.asarray(ctx.get("actor_b_signal_history", []), dtype=float)

    a_rms = float(np.sqrt(np.mean(a ** 2))) if len(a) else 0.0
    b_rms = float(np.sqrt(np.mean(b ** 2))) if len(b) else 0.0
    a_active = a_rms > snapshot.actor_activity_floor
    b_active = b_rms > snapshot.actor_activity_floor

    coordination, lag = (core.max_cross_correlation(a, b)
                         if len(a) >= 4 and len(b) >= 4 else (0.0, 0))
    colluding = bool(a_active and b_active and coordination >= snapshot.coordination_floor)

    if colluding:
        regime = "coordinated"
    elif a_active or b_active:
        regime = "independent_manipulation"
    else:
        regime = "quiet"

    score = 0.0
    score += 3.0 if tput_disrupted else 0.0
    score += 3.0 if price_manipulated else 0.0
    score += 2.0 if a_active else 0.0
    score += 2.0 if b_active else 0.0
    score += 5.0 if colluding else 0.0          # coordinated manipulation is the severe state

    return core.RiskOutput(
        adapter_name="shipping_lane",
        metric_score=float(score),
        confidence_rating=0.94,
        meta_payload={
            "throughput_deviation_frac": tput_dev,
            "price_deviation_frac": price_dev,
            "actor_a_active": a_active,
            "actor_b_active": b_active,
            "actor_a_rms": a_rms,
            "actor_b_rms": b_rms,
            "coordination": coordination,
            "coordination_lag": lag,
            "colluding": colluding,
            "regime": regime,
        },
    )
