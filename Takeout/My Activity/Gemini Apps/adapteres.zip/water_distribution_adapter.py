"""
water_distribution_adapter.py

Distinctive parameters: hydraulic pressure (head), NPSH cavitation margin
(pump-damage signal), network mass-balance residual (leak/theft signal), and
pressure transients (water hammer).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

import dynamics_core as core


@dataclass
class WaterSnapshot:
    pressure_m: float
    flow_lps: float
    pump_speed_pct: float
    npsh_available_m: float
    npsh_required_m: float
    inflow_lps: float
    outflow_lps: float
    storage_delta_lps: float          # d(stored volume)/dt as a flow
    pressure_min_m: float = 20.0       # below -> supply failure / contamination ingress
    pressure_max_m: float = 80.0       # above -> burst risk
    mass_balance_tol_lps: float = 5.0
    pressure_surge_threshold_m: float = 15.0
    context: Optional[Dict[str, Any]] = None   # pressure_history (m)


def pump_system_adapter(snapshot: WaterSnapshot) -> core.RiskOutput:
    p = snapshot.pressure_m
    press_low = max(0.0, snapshot.pressure_min_m - p)
    press_high = max(0.0, p - snapshot.pressure_max_m)

    npsh_margin = snapshot.npsh_available_m - snapshot.npsh_required_m   # <=0 -> cavitation
    cavitation = npsh_margin <= 0.0

    residual = snapshot.inflow_lps - snapshot.outflow_lps - snapshot.storage_delta_lps
    mass_imbalance = abs(residual) > snapshot.mass_balance_tol_lps

    ctx = snapshot.context or {}
    p_hist = np.asarray(ctx.get("pressure_history", []), dtype=float)
    max_surge = float(np.max(np.abs(np.diff(p_hist)))) if len(p_hist) >= 2 else 0.0
    water_hammer = max_surge > snapshot.pressure_surge_threshold_m

    score = 0.0
    score += 4.0 if press_low > 0.0 else 0.0          # supply loss / ingress
    score += 3.0 if press_high > 0.0 else 0.0         # burst risk
    score += 6.0 if cavitation else 0.0               # pump destruction
    score += 4.0 if mass_imbalance else 0.0           # leak / unauthorized draw
    score += 3.0 if water_hammer else 0.0             # transient surge

    return core.RiskOutput(
        adapter_name="pump_system",
        metric_score=float(score),
        confidence_rating=0.96,
        meta_payload={
            "pressure_low_excursion_m": press_low,
            "pressure_high_excursion_m": press_high,
            "npsh_margin_m": npsh_margin,
            "cavitation": cavitation,
            "mass_balance_residual_lps": residual,
            "mass_imbalance": mass_imbalance,
            "max_pressure_surge_m": max_surge,
            "water_hammer": water_hammer,
        },
    )
