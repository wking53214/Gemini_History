"""
power_grid_adapter.py

Distinctive parameters: frequency (Hz), ROCOF (rate of change of frequency --
the inertia-loss signal), per-unit voltage, and inter-area phase-angle
oscillation (small-signal stability).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

import dynamics_core as core


@dataclass
class GridSnapshot:
    frequency_hz: float
    rocof_hz_s: float                 # df/dt
    voltage_pu: float
    nominal_hz: float = 60.0
    freq_band_hz: float = 0.05        # allowed |f - nominal|
    rocof_limit_hz_s: float = 0.5
    voltage_low_pu: float = 0.95
    voltage_high_pu: float = 1.05
    osc_amplitude_floor_deg: float = 1.0
    context: Optional[Dict[str, Any]] = None   # area_angle_diff_history: inter-area angle (deg)


def grid_stability_adapter(snapshot: GridSnapshot) -> core.RiskOutput:
    freq_exc = max(0.0, abs(snapshot.frequency_hz - snapshot.nominal_hz) - snapshot.freq_band_hz)
    rocof_exc = max(0.0, abs(snapshot.rocof_hz_s) - snapshot.rocof_limit_hz_s)
    v = snapshot.voltage_pu
    volt_exc = max(0.0, snapshot.voltage_low_pu - v, v - snapshot.voltage_high_pu)

    score = 0.0
    score += 4.0 if freq_exc > 0.0 else 0.0
    score += 5.0 if rocof_exc > 0.0 else 0.0          # high ROCOF == lost inertia
    score += 3.0 if volt_exc > 0.0 else 0.0

    # Inter-area small-signal instability: is the angle oscillation GROWING?
    ctx = snapshot.context or {}
    angle_hist = np.asarray(ctx.get("area_angle_diff_history", []), dtype=float)
    osc_growth = 0.0
    growing_oscillation = False
    if len(angle_hist) >= 8:
        amplitude = float(np.std(angle_hist))
        osc_growth = core.oscillation_growth_rate(angle_hist)
        growing_oscillation = bool(osc_growth > 0.0 and amplitude > snapshot.osc_amplitude_floor_deg)
        if growing_oscillation:
            score += 5.0

    return core.RiskOutput(
        adapter_name="grid_stability",
        metric_score=float(score),
        confidence_rating=0.97,
        meta_payload={
            "freq_excursion_hz": freq_exc,
            "rocof_excursion_hz_s": rocof_exc,
            "voltage_excursion_pu": volt_exc,
            "oscillation_growth_rate": osc_growth,
            "growing_oscillation": growing_oscillation,
        },
    )
