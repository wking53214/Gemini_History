"""
traffic_routing_adapter.py

Distinctive parameters: the non-monotone flow/density fundamental diagram
(congested vs free-flow regime), queue spillback, and route-choice oscillation
(a feedback-induced instability in the discrete routing decision itself).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

import dynamics_core as core


@dataclass
class TrafficSnapshot:
    flow_vph: float
    density_vpk: float
    capacity_vph: float
    critical_density_vpk: float        # density at capacity (peak of fundamental diagram)
    queue_len_veh: float = 0.0
    queue_capacity_veh: float = 100.0
    route_oscillation_tol: float = 0.20   # std of a route's share above this == flip-flopping
    context: Optional[Dict[str, Any]] = None   # route_share_history: share on route A in [0,1]


def traffic_routing_adapter(snapshot: TrafficSnapshot) -> core.RiskOutput:
    voc = snapshot.flow_vph / snapshot.capacity_vph if snapshot.capacity_vph > 0 else 0.0
    over_capacity = voc > 1.0

    # Past the critical density with flow falling away from capacity == jam branch.
    jam_onset = (snapshot.density_vpk > snapshot.critical_density_vpk
                 and snapshot.flow_vph < 0.9 * snapshot.capacity_vph)

    spillback = (snapshot.queue_capacity_veh > 0
                 and snapshot.queue_len_veh / snapshot.queue_capacity_veh >= 0.9)

    ctx = snapshot.context or {}
    shares = np.asarray(ctx.get("route_share_history", []), dtype=float)
    share_jitter = float(np.std(shares)) if len(shares) >= 4 else 0.0
    route_oscillation = share_jitter > snapshot.route_oscillation_tol

    score = 0.0
    score += 4.0 if over_capacity else 0.0
    score += 3.0 if jam_onset else 0.0
    score += 4.0 if spillback else 0.0
    score += 3.0 if route_oscillation else 0.0

    return core.RiskOutput(
        adapter_name="traffic_routing",
        metric_score=float(score),
        confidence_rating=0.95,
        meta_payload={
            "volume_over_capacity": voc,
            "over_capacity": over_capacity,
            "jam_onset": jam_onset,
            "spillback": spillback,
            "route_share_jitter": share_jitter,
            "route_oscillation": route_oscillation,
        },
    )
