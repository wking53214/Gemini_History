"""
black_hole_mapping_adapter.py

Mapping a black hole from interferometric (VLBI / EHT-style) data. This is NOT
a control system -- it is an inverse-inference system, so the semantics are
INVERTED: a high risk score means "do not trust this map", not "the object is
unstable".

Distinctive parameters: posterior uncertainty on an inferred latent physical
parameter (1-sigma on the dimensionless Kerr spin a*), the conditioning of the
inverse problem (uv-coverage fraction), data-model fit quality (chi-square per
dof), calibration scatter, and a hard relativistic bound (a* must lie in [0, 1];
outside it the fit is unphysical and is rejected).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import dynamics_core as core


@dataclass
class BlackHoleMapSnapshot:
    chi2_per_dof: float
    uv_coverage_fraction: float        # fraction of the Fourier (uv) plane sampled, [0, 1]
    calib_phase_rms_deg: float         # station gain-phase calibration scatter
    spin_estimate: float               # dimensionless Kerr spin a*
    spin_posterior_sigma: float        # 1-sigma uncertainty on a*
    mass_estimate_msun: float
    chi2_low: float = 0.8
    chi2_high: float = 1.5
    uv_coverage_min: float = 0.4
    calib_phase_rms_max_deg: float = 30.0
    spin_sigma_max: float = 0.2        # wider posterior -> spin effectively unconstrained
    context: Optional[Dict[str, Any]] = None


def black_hole_mapping_adapter(snapshot: BlackHoleMapSnapshot) -> core.RiskOutput:
    # Hard physical-validity gate: Kerr bound on dimensionless spin.
    unphysical = not (0.0 <= snapshot.spin_estimate <= 1.0)

    c = snapshot.chi2_per_dof
    fit_bad = c < snapshot.chi2_low or c > snapshot.chi2_high
    under_constrained = snapshot.uv_coverage_fraction < snapshot.uv_coverage_min
    calibration_bad = snapshot.calib_phase_rms_deg > snapshot.calib_phase_rms_max_deg
    spin_unconstrained = snapshot.spin_posterior_sigma > snapshot.spin_sigma_max

    score = 0.0
    score += 10.0 if unphysical else 0.0          # fit violates relativity -> reject
    score += 4.0 if fit_bad else 0.0
    score += 4.0 if under_constrained else 0.0    # ill-posed reconstruction
    score += 4.0 if calibration_bad else 0.0
    score += 3.0 if spin_unconstrained else 0.0   # the headline parameter is not identified

    # Adapter confidence tracks how well-posed the inversion is (coverage).
    confidence = max(0.3, min(0.97, snapshot.uv_coverage_fraction))

    return core.RiskOutput(
        adapter_name="black_hole_mapping",
        metric_score=float(score),
        confidence_rating=float(confidence),
        meta_payload={
            "spin_estimate": snapshot.spin_estimate,
            "unphysical_spin": unphysical,
            "chi2_per_dof": c,
            "fit_bad": fit_bad,
            "uv_coverage_fraction": snapshot.uv_coverage_fraction,
            "under_constrained": under_constrained,
            "calib_phase_rms_deg": snapshot.calib_phase_rms_deg,
            "calibration_bad": calibration_bad,
            "spin_posterior_sigma": snapshot.spin_posterior_sigma,
            "spin_unconstrained": spin_unconstrained,
            "note": "high score == low trust in the reconstructed map (inverted semantics)",
        },
    )
